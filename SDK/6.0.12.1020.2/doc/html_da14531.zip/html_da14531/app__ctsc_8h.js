var app__ctsc_8h =
[
    [ "app_ctsc_create_task", "group___c_t_s_c.html#gaf66a0002fc513c8a6e0f31137c019718", null ],
    [ "app_ctsc_enable", "group___c_t_s_c.html#gaa4241f63253aebc993d51647b89037b1", null ],
    [ "app_ctsc_init", "group___c_t_s_c.html#ga8db5c4c233a5c5aa4bb3c15ebd8d7637", null ],
    [ "app_ctsc_read_ct", "group___c_t_s_c.html#ga6bd5c23438f76863932d605c385d66cc", null ],
    [ "app_ctsc_read_desc", "group___c_t_s_c.html#ga70e3c7a72b2d311170fd4aedfb43c58b", null ],
    [ "app_ctsc_read_lti", "group___c_t_s_c.html#ga7eb94419936d142c98965ee2a77abd64", null ],
    [ "app_ctsc_read_rti", "group___c_t_s_c.html#ga60f262d1db8d33fe1b9827e805321973", null ],
    [ "app_ctsc_write_ct", "group___c_t_s_c.html#ga9782b4d052d10b1a547ae77b3e440bbe", null ],
    [ "app_ctsc_write_desc", "group___c_t_s_c.html#gaed144075fd5632c11ead9d60cded19d6", null ],
    [ "app_ctsc_write_lti", "group___c_t_s_c.html#ga4e9d007b0aa1f0e12b12aa2bc0874f43", null ]
];