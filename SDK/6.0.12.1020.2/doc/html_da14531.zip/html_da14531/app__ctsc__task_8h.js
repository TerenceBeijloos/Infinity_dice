var app__ctsc__task_8h =
[
    [ "APP_CTS_IDX_MAX", "app__ctsc__task_8h.html#aae9fc060c0682f97aa5cf5fd58e80ed7", null ],
    [ "app_ctsc_process_handler", "app__ctsc__task_8h.html#a67eaf9db39b0bbe52fbffb9aff955753", null ]
];