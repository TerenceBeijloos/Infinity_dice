var app__customs_8h =
[
    [ "app_custs1_create_db", "group___c_u_s_t_o_m_s.html#ga2e944b7bca061cb328f30e4f006397f9", null ],
    [ "app_custs1_enable", "group___c_u_s_t_o_m_s.html#gaae38c80aad3dc345977722fd17ebe291", null ],
    [ "app_custs1_init", "group___c_u_s_t_o_m_s.html#ga3200734cb8810a13304702d60abea1f3", null ],
    [ "app_custs1_val_wr_validate", "group___c_u_s_t_o_m_s.html#gadd1cda5f047dee28f5bb5222c4a7c092", null ],
    [ "app_custs2_create_db", "group___c_u_s_t_o_m_s.html#gaba866f5c840402bb4e8c87cceff2d2cf", null ],
    [ "app_custs2_enable", "group___c_u_s_t_o_m_s.html#ga41074dbb24bf0d9a7b78e709549b1a4d", null ],
    [ "app_custs2_init", "group___c_u_s_t_o_m_s.html#ga401cbd1d43e675f1027188a6c89957e1", null ],
    [ "app_custs2_val_wr_validate", "group___c_u_s_t_o_m_s.html#gac8e3261ffaf61f7f661f57527c1a99ee", null ],
    [ "custs_get_func_callbacks", "group___c_u_s_t_o_m_s.html#ga2694e66127080bbc8b42a813698b168d", null ]
];