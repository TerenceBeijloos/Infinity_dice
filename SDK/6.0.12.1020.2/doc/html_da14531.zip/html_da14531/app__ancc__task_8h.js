var app__ancc__task_8h =
[
    [ "APP_ANC_IDX_MAX", "app__ancc__task_8h.html#ae7d666d5fcdc4d211250dcdd4a993098", null ],
    [ "app_ancc_process_handler", "app__ancc__task_8h.html#a1869ebf84f8179468f29ba0c93f52434", null ]
];