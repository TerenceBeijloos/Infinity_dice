var app__utils_8h =
[
    [ "app_addr_types", "group___utils.html#ga61c8669a6fec4820f7962bba8c99da68", [
      [ "APP_PUBLIC_ADDR_TYPE", "group___utils.html#gga61c8669a6fec4820f7962bba8c99da68aece08517157c8fb3d6e809c698bbad2d", null ],
      [ "APP_RANDOM_STATIC_ADDR_TYPE", "group___utils.html#gga61c8669a6fec4820f7962bba8c99da68ae64d10e89d1fb47a6fb3a109d92d6da6", null ],
      [ "APP_RANDOM_PRIVATE_RESOLV_ADDR_TYPE", "group___utils.html#gga61c8669a6fec4820f7962bba8c99da68a2c1ca33036d4b78c1fe7fbeb2003c66d", null ],
      [ "APP_RANDOM_PRIVATE_NONRESOLV_ADDR_TYPE", "group___utils.html#gga61c8669a6fec4820f7962bba8c99da68af37f6e111e4014bc2c714ecdf5989ce5", null ],
      [ "APP_ID_ADDR_TYPE", "group___utils.html#gga61c8669a6fec4820f7962bba8c99da68ae34f0c91bc2ecface7b12fb420807be5", null ],
      [ "APP_ERROR_ADDR_TYPE", "group___utils.html#gga61c8669a6fec4820f7962bba8c99da68a34927b666da364d75a090ffbe6c55564", null ]
    ] ],
    [ "app_ral_operations", "group___utils.html#gaa167740075f81789edad7e1fc976bc18", [
      [ "APP_GET_RAL_SIZE", "group___utils.html#ggaa167740075f81789edad7e1fc976bc18ac313eabc65ff31ae06192aa6abb932d7", null ],
      [ "APP_GET_RAL_LOC_ADDR", "group___utils.html#ggaa167740075f81789edad7e1fc976bc18a5b10471f4b62a08a839e2e5d7d9ddddd", null ],
      [ "APP_GET_RAL_PEER_ADDR", "group___utils.html#ggaa167740075f81789edad7e1fc976bc18a0fce83ea78d7ce1620edc79ce414aaa9", null ],
      [ "APP_ADD_DEV_IN_RAL", "group___utils.html#ggaa167740075f81789edad7e1fc976bc18a0a9d50beb6483d1337ac8a3d9a479d2f", null ],
      [ "APP_RMV_DEV_FRM_RAL", "group___utils.html#ggaa167740075f81789edad7e1fc976bc18a62892ef12650a0014d67cd3048c5ba51", null ],
      [ "APP_CLEAR_RAL", "group___utils.html#ggaa167740075f81789edad7e1fc976bc18ab28f7fdb98c19ce9bc0b65491c86244e", null ],
      [ "APP_NETWORK_MODE_RAL", "group___utils.html#ggaa167740075f81789edad7e1fc976bc18a83e3d355eb0ca0bd82a9b25427350c8d", null ],
      [ "APP_DEVICE_MODE_RAL", "group___utils.html#ggaa167740075f81789edad7e1fc976bc18a4e3fcad36442092f583a99008f3b239a", null ]
    ] ],
    [ "app_fill_random_byte_array", "group___utils.html#ga50ac1ba1b88271b2a694c9a100247f2d", null ],
    [ "app_get_address_type", "group___utils.html#ga4e1add4af25e1e4fd8b8db7f0060ff61", null ]
];