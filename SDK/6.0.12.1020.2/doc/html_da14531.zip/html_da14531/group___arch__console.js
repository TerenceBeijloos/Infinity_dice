var group___arch__console =
[
    [ "arch_console.h", "arch__console_8h.html", null ],
    [ "__print_msg", "struct____print__msg.html", [
      [ "pBuf", "struct____print__msg.html#aa60f2a9ce4071109c9f19b20b9b5f999", null ],
      [ "pNext", "struct____print__msg.html#ae248120c3ac92196d1bc1feabd907237", null ]
    ] ],
    [ "rom_console_cfg_t", "structrom__console__cfg__t.html", [
      [ "arch_force_active_mode", "structrom__console__cfg__t.html#a2cc76a5293430f245fd99678737ead62", null ],
      [ "arch_restore_sleep_mode", "structrom__console__cfg__t.html#a332e7bcddba3c1f7476ead9aa5450d40", null ],
      [ "current_msg_buffer", "structrom__console__cfg__t.html#a2095b72648ede339601d391d5d6248d1", null ],
      [ "current_msg_offset", "structrom__console__cfg__t.html#ad8a7b3dcbd8137a16443bb1023e763df", null ],
      [ "defer_sending", "structrom__console__cfg__t.html#a1cd145032327a98484a7e060fbb10a61", null ],
      [ "printf_msg_list", "structrom__console__cfg__t.html#ac2c6270e3f6770cd36ea1f5ef3993f69", null ],
      [ "uart_busy", "structrom__console__cfg__t.html#a5dc07ef6276b467e813e2a8733e2db3c", null ],
      [ "uart_finish", "structrom__console__cfg__t.html#aa61fe2aedcfb2c589220ba5c9ff05769", null ],
      [ "uart_write", "structrom__console__cfg__t.html#a290c035d767a24417dc0586a9f4c28ff", null ]
    ] ],
    [ "printf_msg", "group___arch__console.html#gaa64f9978438adfd8be6871a2382c69f1", null ],
    [ "arch_printf", "group___arch__console.html#ga2fccf9d1ac109c6cb0cfab2d4937e597", null ],
    [ "arch_printf_flush", "group___arch__console.html#gab4d63b01e9027bf2176e396ab3053738", null ],
    [ "arch_printf_process", "group___arch__console.html#ga047ae17df2c5c8fe7a8bb1f7011d7fbe", null ],
    [ "arch_puts", "group___arch__console.html#gaa01e27d70717addba726d86b82af5ee3", null ],
    [ "arch_vprintf", "group___arch__console.html#ga3d341c0fabf18c6dd8cf890943eca77e", null ]
];