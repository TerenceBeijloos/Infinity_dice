var app__diss__task_8h =
[
    [ "APP_DIS_IDX_MAX", "app__diss__task_8h.html#ad84025034c5cf4ad4a26d91913fce7db", null ],
    [ "app_diss_process_handler", "app__diss__task_8h.html#ada98f2e1634d57380ed9399aa0d2cff0", null ]
];