var group___a_r_c_h =
[
    [ "System", "group___a_r_c_h___s_y_s_t_e_m.html", "group___a_r_c_h___s_y_s_t_e_m" ],
    [ "RAM Utilities", "group___a_r_c_h___r_a_m.html", "group___a_r_c_h___r_a_m" ],
    [ "ROM Utilities", "group___a_r_c_h___r_o_m.html", "group___a_r_c_h___r_o_m" ],
    [ "Watchdog", "group___a_r_c_h___w_d_g.html", "group___a_r_c_h___w_d_g" ]
];