var app__gattc_8h =
[
    [ "app_gattc_create_task", "group___g_a_t_t_c.html#gaf3f1f1185b21103247660b2922370d4f", null ],
    [ "app_gattc_enable", "group___g_a_t_t_c.html#gade134ec163db4d137e3e7ed79833e7cc", null ],
    [ "app_gattc_init", "group___g_a_t_t_c.html#gaa58b40bbd52892c552133cb413dee563", null ],
    [ "app_gattc_read_ind_cfg", "group___g_a_t_t_c.html#ga34cf4342add8d1f2bcafb479023ecec9", null ],
    [ "app_gattc_write_ind_cfg", "group___g_a_t_t_c.html#gac26b376b1a0495a93664e8cc49bd4353", null ]
];