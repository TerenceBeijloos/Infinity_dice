var battery_8h =
[
    [ "batt_t", "group___battery.html#ga28e12856e4c0bf56a588645ddd39ec7f", [
      [ "BATT_CR2032", "group___battery.html#gga28e12856e4c0bf56a588645ddd39ec7fa45aad6e0a30070b8fbd62fcf832cfcd3", null ],
      [ "BATT_ALKALINE", "group___battery.html#gga28e12856e4c0bf56a588645ddd39ec7fa92663983fcd4f4f7b102d69cc7f6d0b0", null ]
    ] ],
    [ "battery_get_lvl", "group___battery.html#ga3de6b950c9008ca44c9d1a84e3b12018", null ],
    [ "battery_get_voltage", "group___battery.html#gac99dda68d97e5a7e71cc20c3d3645950", null ]
];