var group___b_a_s_s =
[
    [ "app_bass.h", "app__bass_8h.html", null ],
    [ "app_bass_cb", "structapp__bass__cb.html", [
      [ "on_batt_level_ntf_cfg_ind", "structapp__bass__cb.html#a2a14cc9b6ff95cea980d68fb7ed0c5b6", null ],
      [ "on_batt_level_upd_rsp", "structapp__bass__cb.html#a5cad12425dc1efa35d779a127b1f45ae", null ]
    ] ],
    [ "app_bass_create_db", "group___b_a_s_s.html#ga5fcc3e1959ce4c4e78bfe3165a89a15d", null ],
    [ "app_bass_enable", "group___b_a_s_s.html#ga2cbf276f29c66c2a02e611aae27c9465", null ],
    [ "app_batt_alert_start", "group___b_a_s_s.html#gad4904b122e6fe4b4a4cedc4bf2587d72", null ],
    [ "app_batt_alert_stop", "group___b_a_s_s.html#gaa9cd4a6c58adaa32c23ce8144e5cfcb9", null ],
    [ "app_batt_config", "group___b_a_s_s.html#ga76576e6c97d7c04abfbb5c2a8b52aafc", null ],
    [ "app_batt_init", "group___b_a_s_s.html#ga1bf262e66e563275b2a0d49d28d68e4a", null ],
    [ "app_batt_lvl", "group___b_a_s_s.html#gab8454220aedcb99ed2ffc61b75cd5c6f", null ],
    [ "app_batt_poll_start", "group___b_a_s_s.html#ga8b88988e204ff6000f6e46bbad82a48a", null ],
    [ "app_batt_poll_stop", "group___b_a_s_s.html#gac3fe4c5032d60f593eabeea12c46590d", null ],
    [ "app_batt_port_reinit", "group___b_a_s_s.html#ga7bc4a2733040989cc08ad6c97f66d36d", null ],
    [ "app_batt_set_level", "group___b_a_s_s.html#ga195063d3de0ab33af113785f86ec5206", null ],
    [ "bat_led_state", "group___b_a_s_s.html#gae4b5b1fba4a47a9a158bc904adb1738f", null ],
    [ "batt_alert_en", "group___b_a_s_s.html#gac8d30db3df772dae19822d0a7421ec6f", null ],
    [ "cur_batt_level", "group___b_a_s_s.html#ga60493bb43c010eda007433af9ffe38f4", null ]
];