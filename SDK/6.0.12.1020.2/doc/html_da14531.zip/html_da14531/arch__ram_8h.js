var arch__ram_8h =
[
    [ "ALL_RAM_BLOCKS", "group___a_r_c_h___r_a_m.html#ga514c9e40fdea9eaa17222cf3b12a76a2", null ],
    [ "RAM_1_BASE_ADDR", "group___a_r_c_h___r_a_m.html#gaaa127ce5337c7ef3faa9c61faf2a5df7", null ],
    [ "RAM_1_BLOCK", "group___a_r_c_h___r_a_m.html#ga55eae0b73c9d700a126c2ece8b8fd339", null ],
    [ "RAM_2_BASE_ADDR", "group___a_r_c_h___r_a_m.html#ga7236364f2ee5ae862f6040988463626f", null ],
    [ "RAM_2_BLOCK", "group___a_r_c_h___r_a_m.html#gae30e93a9b03c7dbc081d7b1e2e57b315", null ],
    [ "RAM_3_BASE_ADDR", "group___a_r_c_h___r_a_m.html#ga2fc681ad772461cca499d84e15f3fdc0", null ],
    [ "RAM_3_BLOCK", "group___a_r_c_h___r_a_m.html#ga54324db96513f1862329dc72c315b86c", null ],
    [ "RAM_4_BLOCK", "group___a_r_c_h___r_a_m.html#gadfe49a828da8c94ba06f4d05a1f568e2", null ],
    [ "RAM_SIZE_80KB_OPT1", "group___a_r_c_h___r_a_m.html#ga9bfb3e3418656c1eceb0d46be611709d", null ],
    [ "RAM_SIZE_80KB_OPT2", "group___a_r_c_h___r_a_m.html#ga4c6c32adb4ab4bface11ae489377e978", null ],
    [ "RAM_SIZE_96KB_OPT1", "group___a_r_c_h___r_a_m.html#ga6069e266ba7f95b13dbf9c4a49ec4f58", null ],
    [ "arch_ram_set_retention_mode", "group___a_r_c_h___r_a_m.html#ga6d9c0a53a92c429e2ee767420da0e053", null ]
];