var gpio_8h =
[
    [ "GPIO_BASE", "group___g_p_i_o.html#gacce3b8a909ed8b957b4e411dfb7cbd91", null ],
    [ "GPIO_POR_PIN_REG", "group___g_p_i_o.html#ga05b2ae6f573ba8e12e2b9dfbf735bd25", null ],
    [ "RESERVE_GPIO", "group___g_p_i_o.html#gaa51bb8cd37d1c92f97b6d070855eae37", null ],
    [ "GPIO_handler_function_t", "group___g_p_i_o.html#ga3c4742240c59320ffb914b552395a76c", null ],
    [ "GPIO_FUNCTION", "group___g_p_i_o.html#ga7cc38ae8fa6cf57d7d3774ccd3dee253", [
      [ "PID_GPIO", "group___g_p_i_o.html#gga7cc38ae8fa6cf57d7d3774ccd3dee253a98da2109893e8c11476f1d0f0a80accc", null ],
      [ "PID_UART1_RX", "group___g_p_i_o.html#gga7cc38ae8fa6cf57d7d3774ccd3dee253a0bcfbac544eb060d3b6ef5d0ec725d5f", null ],
      [ "PID_UART1_TX", "group___g_p_i_o.html#gga7cc38ae8fa6cf57d7d3774ccd3dee253acec27de707a6ca77b8f1983c92abf504", null ],
      [ "PID_UART2_RX", "group___g_p_i_o.html#gga7cc38ae8fa6cf57d7d3774ccd3dee253aae4a83a85cf93b16b76e0a93497e7292", null ],
      [ "PID_UART2_TX", "group___g_p_i_o.html#gga7cc38ae8fa6cf57d7d3774ccd3dee253a9094635d2181993bccd616016d1d2b32", null ],
      [ "PID_SYS_CLK", "group___g_p_i_o.html#gga7cc38ae8fa6cf57d7d3774ccd3dee253a0fa4a4c54cc41d70b4403ea368d3356f", null ],
      [ "PID_LP_CLK", "group___g_p_i_o.html#gga7cc38ae8fa6cf57d7d3774ccd3dee253a21575093ab3c8e7454a90b30f9583d49", null ],
      [ "PID_I2C_SCL", "group___g_p_i_o.html#gga7cc38ae8fa6cf57d7d3774ccd3dee253abde47cd30a7cdda248f54bc13bf0199e", null ],
      [ "PID_I2C_SDA", "group___g_p_i_o.html#gga7cc38ae8fa6cf57d7d3774ccd3dee253a023848dba5a3b14c5c923e4483e69577", null ],
      [ "PID_PWM5", "group___g_p_i_o.html#gga7cc38ae8fa6cf57d7d3774ccd3dee253a51ada1796517ffc7b2e420ec91f812d6", null ],
      [ "PID_PWM6", "group___g_p_i_o.html#gga7cc38ae8fa6cf57d7d3774ccd3dee253a8ef94703b710f55515c939e029de9697", null ],
      [ "PID_PWM7", "group___g_p_i_o.html#gga7cc38ae8fa6cf57d7d3774ccd3dee253af6d320efd66090d0a80d6efcc97a7ded", null ],
      [ "PID_ADC", "group___g_p_i_o.html#gga7cc38ae8fa6cf57d7d3774ccd3dee253a20ab4d2b36e3106caa72b6e3a7cd25be", null ],
      [ "PID_PWM0", "group___g_p_i_o.html#gga7cc38ae8fa6cf57d7d3774ccd3dee253a7ed54096fe45229e90fdfbab07c6f8ba", null ],
      [ "PID_PWM1", "group___g_p_i_o.html#gga7cc38ae8fa6cf57d7d3774ccd3dee253af2d35e6a392a5fb9691d6e592b9fd362", null ],
      [ "PID_BLE_DIAG", "group___g_p_i_o.html#gga7cc38ae8fa6cf57d7d3774ccd3dee253ade84ed6d6794a77fabc0d82e859a23b7", null ],
      [ "PID_UART1_CTSN", "group___g_p_i_o.html#gga7cc38ae8fa6cf57d7d3774ccd3dee253a1f903f722b928dd7149d60fd3bc36a20", null ],
      [ "PID_UART1_RTSN", "group___g_p_i_o.html#gga7cc38ae8fa6cf57d7d3774ccd3dee253a2148ea348eda4754b3037fbda2eca0bf", null ],
      [ "PID_PWM2", "group___g_p_i_o.html#gga7cc38ae8fa6cf57d7d3774ccd3dee253aad2207086f99c6b9f3c2f96f0c40c27a", null ],
      [ "PID_PWM3", "group___g_p_i_o.html#gga7cc38ae8fa6cf57d7d3774ccd3dee253ad536dd536900e06680fedb80b92bbff1", null ],
      [ "PID_PWM4", "group___g_p_i_o.html#gga7cc38ae8fa6cf57d7d3774ccd3dee253aee0719197138a21b925c39e2fb936ca5", null ],
      [ "PID_SPI_DI", "group___g_p_i_o.html#gga7cc38ae8fa6cf57d7d3774ccd3dee253a7c9d0e3ab8d5f7503e0158c2e0719140", null ],
      [ "PID_SPI_DO", "group___g_p_i_o.html#gga7cc38ae8fa6cf57d7d3774ccd3dee253a3faf7b726b19dfcd07ae3fc78d811715", null ],
      [ "PID_SPI_CLK", "group___g_p_i_o.html#gga7cc38ae8fa6cf57d7d3774ccd3dee253ab335c62bf34dc7c7b971334f2c71e761", null ],
      [ "PID_SPI_EN", "group___g_p_i_o.html#gga7cc38ae8fa6cf57d7d3774ccd3dee253a30c4dec9953add46c481c15f3aee1c8b", null ],
      [ "PID_SPI_EN1", "group___g_p_i_o.html#gga7cc38ae8fa6cf57d7d3774ccd3dee253a3c301c4970083a10f61dbcb598eea9b7", null ]
    ] ],
    [ "GPIO_IRQ_INPUT_LEVEL", "group___g_p_i_o.html#gab4cc4d6c9bad19708a1f9ffacf3ec92b", [
      [ "GPIO_IRQ_INPUT_LEVEL_HIGH", "group___g_p_i_o.html#ggab4cc4d6c9bad19708a1f9ffacf3ec92bad79452209578ee3c9e2008f14d0f81b9", null ],
      [ "GPIO_IRQ_INPUT_LEVEL_LOW", "group___g_p_i_o.html#ggab4cc4d6c9bad19708a1f9ffacf3ec92bacb5027de98d0508ceb4b2e47b4413902", null ]
    ] ],
    [ "GPIO_PIN", "group___g_p_i_o.html#gaa996b1dc8b3c8150f9319cf7d33336b0", [
      [ "GPIO_PIN_0", "group___g_p_i_o.html#ggaa996b1dc8b3c8150f9319cf7d33336b0a17ff2661bc18516d4b4db44697dca94d", null ],
      [ "GPIO_PIN_1", "group___g_p_i_o.html#ggaa996b1dc8b3c8150f9319cf7d33336b0a2646a74b5754d457b70d3337d5c6f0df", null ],
      [ "GPIO_PIN_2", "group___g_p_i_o.html#ggaa996b1dc8b3c8150f9319cf7d33336b0aec3b1d7c31ae09b65edc3d23e35e649e", null ],
      [ "GPIO_PIN_3", "group___g_p_i_o.html#ggaa996b1dc8b3c8150f9319cf7d33336b0a8ebb137cd9615643af156b2db1baf65b", null ],
      [ "GPIO_PIN_4", "group___g_p_i_o.html#ggaa996b1dc8b3c8150f9319cf7d33336b0ad98b35c6b79dad7139c6dea3028c3f6a", null ],
      [ "GPIO_PIN_5", "group___g_p_i_o.html#ggaa996b1dc8b3c8150f9319cf7d33336b0a7e50b13a509d1490126f0054738407c8", null ],
      [ "GPIO_PIN_6", "group___g_p_i_o.html#ggaa996b1dc8b3c8150f9319cf7d33336b0a574437e4ceac78092d220c0a4bfdcb52", null ],
      [ "GPIO_PIN_7", "group___g_p_i_o.html#ggaa996b1dc8b3c8150f9319cf7d33336b0ac09c13611156e06753569192b7ea9016", null ],
      [ "GPIO_PIN_8", "group___g_p_i_o.html#ggaa996b1dc8b3c8150f9319cf7d33336b0aacbbe1caed65d70511d9de048f37146a", null ],
      [ "GPIO_PIN_9", "group___g_p_i_o.html#ggaa996b1dc8b3c8150f9319cf7d33336b0ac98e7c0828240123d457d5fae81a9513", null ],
      [ "GPIO_PIN_10", "group___g_p_i_o.html#ggaa996b1dc8b3c8150f9319cf7d33336b0ac93b4052ed2cfa8dac6c5827c9091526", null ],
      [ "GPIO_PIN_11", "group___g_p_i_o.html#ggaa996b1dc8b3c8150f9319cf7d33336b0a8f476ac3b71ae4e296abcaf326e9580a", null ]
    ] ],
    [ "GPIO_POR_PIN_POLARITY", "group___g_p_i_o.html#gaa204aad1a8f88f2905f4684acdd89231", [
      [ "GPIO_POR_PIN_POLARITY_LOW", "group___g_p_i_o.html#ggaa204aad1a8f88f2905f4684acdd89231afde3e6fdf959996a15fc6e4c833da927", null ],
      [ "GPIO_POR_PIN_POLARITY_HIGH", "group___g_p_i_o.html#ggaa204aad1a8f88f2905f4684acdd89231ae9e9954e30a393aa4fab10a0774d50f9", null ]
    ] ],
    [ "GPIO_PORT", "group___g_p_i_o.html#ga40010ecd5fc233aeb2cedf70284b2996", [
      [ "GPIO_PORT_0", "group___g_p_i_o.html#gga40010ecd5fc233aeb2cedf70284b2996a8b715b84d16b206ee05d4fb3c98d414c", null ]
    ] ],
    [ "GPIO_POWER_RAIL", "group___g_p_i_o.html#ga37c07d9951f2ab0bcb5ce3facca4504d", [
      [ "GPIO_POWER_RAIL_3V", "group___g_p_i_o.html#gga37c07d9951f2ab0bcb5ce3facca4504dacb44e7aaaca44948761ed5bffc7dc895", null ],
      [ "GPIO_POWER_RAIL_1V", "group___g_p_i_o.html#gga37c07d9951f2ab0bcb5ce3facca4504da75d46767ed766cb80a5c27e5efb34adb", null ]
    ] ],
    [ "GPIO_PUPD", "group___g_p_i_o.html#gab1076c042891e1520d9dd24800932559", [
      [ "INPUT", "group___g_p_i_o.html#ggab1076c042891e1520d9dd24800932559ae310c909d76b003d016bef8bdf16936a", null ],
      [ "INPUT_PULLUP", "group___g_p_i_o.html#ggab1076c042891e1520d9dd24800932559a851c2ac60276ada62e8d9ba216c7a487", null ],
      [ "INPUT_PULLDOWN", "group___g_p_i_o.html#ggab1076c042891e1520d9dd24800932559a58b097229d3b2a4afa0eb445c1334927", null ],
      [ "OUTPUT", "group___g_p_i_o.html#ggab1076c042891e1520d9dd24800932559a2ab08d3e103968f5f4f26b66a52e99d6", null ]
    ] ],
    [ "GPIO_ConfigurePin", "group___g_p_i_o.html#ga8a35707efc49d3bf2b356e4fd0b47ee5", null ],
    [ "GPIO_ConfigurePinPower", "group___g_p_i_o.html#gae28e85f3cc7bef78fcf3d7273742f9da", null ],
    [ "GPIO_Disable_HW_Reset", "group___g_p_i_o.html#ga32eae400d103d97bcfd58814dcbe4f87", null ],
    [ "GPIO_DisablePorPin", "group___g_p_i_o.html#gab833cdfdada9ec3acfedad8728d05489", null ],
    [ "GPIO_Enable_HW_Reset", "group___g_p_i_o.html#gabb0c4803a4bb698ac75a5ef57080d22d", null ],
    [ "GPIO_EnableIRQ", "group___g_p_i_o.html#ga578386f3b8bbbc60c04b66d1c53e6274", null ],
    [ "GPIO_EnablePorPin", "group___g_p_i_o.html#gacc78e017db134ffa24847c0dc1eaf30a", null ],
    [ "GPIO_GetIRQInputLevel", "group___g_p_i_o.html#gac532901bcf9aec6200ac0c43a22be409", null ],
    [ "GPIO_GetPinFunction", "group___g_p_i_o.html#gaf21667d1d357977640e953f1ee6cecc6", null ],
    [ "GPIO_GetPinStatus", "group___g_p_i_o.html#gaac397189f2e4d9bff11db0c38163285d", null ],
    [ "GPIO_GetPorTime", "group___g_p_i_o.html#ga5a08653ae6a0a7e69e1cdfd65f1baf6d", null ],
    [ "GPIO_init", "group___g_p_i_o.html#ga75690af9e89afd801dc40b20b5c813f1", null ],
    [ "GPIO_is_valid", "group___g_p_i_o.html#gad8a06d370092bf09f4aef5512229ac16", null ],
    [ "GPIO_RegisterCallback", "group___g_p_i_o.html#gaaa5de0a9aa0d7a6e52b400bf39c85f11", null ],
    [ "GPIO_ResetIRQ", "group___g_p_i_o.html#gac291fe1f17ccfee06c58f41e7ee3b022", null ],
    [ "GPIO_set_pad_latch_en", "group___g_p_i_o.html#gaee6a89743225a10670d73fdf53b0cb64", null ],
    [ "GPIO_SetActive", "group___g_p_i_o.html#ga773266cec17b93191fa3566da078054b", null ],
    [ "GPIO_SetInactive", "group___g_p_i_o.html#ga1f8189fc7531d237061cc57c1dcf0f7a", null ],
    [ "GPIO_SetIRQInputLevel", "group___g_p_i_o.html#ga369de2bfab9e5822f6ef03fdf894fcbf", null ],
    [ "GPIO_SetPinFunction", "group___g_p_i_o.html#ga7233c4d8592e16567f4f06d730a84f9d", null ],
    [ "GPIO_SetPorTime", "group___g_p_i_o.html#gadbc096f37b5989a81bcff334ff3a2617", null ]
];