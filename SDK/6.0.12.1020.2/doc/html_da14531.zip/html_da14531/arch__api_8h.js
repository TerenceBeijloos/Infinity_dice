var arch__api_8h =
[
    [ "LP_CLK_FROM_OTP", "group___a_r_c_h___s_y_s_t_e_m.html#ga3110653c0c94784f2f57c9e5e085ba4d", null ],
    [ "LP_CLK_RCX20", "group___a_r_c_h___s_y_s_t_e_m.html#ga9c0692827bfa063fece9aa308d980c59", null ],
    [ "LP_CLK_XTAL32", "group___a_r_c_h___s_y_s_t_e_m.html#gaeca19c86b2f4b4ca95a5d9daa86e9022", null ],
    [ "arch_main_loop_callback_ret_t", "group___a_r_c_h___s_y_s_t_e_m.html#ga5f26de7c4412f34a185d38e9477a077f", [
      [ "GOTO_SLEEP", "group___a_r_c_h___s_y_s_t_e_m.html#gga5f26de7c4412f34a185d38e9477a077fa4d9aa40bb41cfa3319d229bac09402b7", null ],
      [ "KEEP_POWERED", "group___a_r_c_h___s_y_s_t_e_m.html#gga5f26de7c4412f34a185d38e9477a077fa322de5a78d1d3f2037e1743032056fb8", null ]
    ] ],
    [ "last_ble_evt", "group___a_r_c_h___s_y_s_t_e_m.html#ga4c5de29ba2314ab328aa495af9854859", [
      [ "BLE_EVT_SLP", "group___a_r_c_h___s_y_s_t_e_m.html#gga4c5de29ba2314ab328aa495af9854859afa53affe0389dda8de1b83cb8780b99b", null ],
      [ "BLE_EVT_CSCNT", "group___a_r_c_h___s_y_s_t_e_m.html#gga4c5de29ba2314ab328aa495af9854859a9b7b9172e179a113f56569c72ba04bca", null ],
      [ "BLE_EVT_RX", "group___a_r_c_h___s_y_s_t_e_m.html#gga4c5de29ba2314ab328aa495af9854859ac823c3bfaffca821b0e7cc49fbf78f1e", null ],
      [ "BLE_EVT_TX", "group___a_r_c_h___s_y_s_t_e_m.html#gga4c5de29ba2314ab328aa495af9854859a0d379579293b530d4fb32a6ffd262eb5", null ],
      [ "BLE_EVT_END", "group___a_r_c_h___s_y_s_t_e_m.html#gga4c5de29ba2314ab328aa495af9854859a3c681b26088f7f217221ddc15300ab3b", null ]
    ] ],
    [ "pd_sys_down_ram_t", "group___a_r_c_h___s_y_s_t_e_m.html#ga90391e5c6ce48bbaeb0eb618423a8b8c", [
      [ "PD_SYS_DOWN_RAM_ON", "group___a_r_c_h___s_y_s_t_e_m.html#gga90391e5c6ce48bbaeb0eb618423a8b8ca3efd28ec23d6a20d6a10240aa6725461", null ],
      [ "PD_SYS_DOWN_RAM_OFF", "group___a_r_c_h___s_y_s_t_e_m.html#gga90391e5c6ce48bbaeb0eb618423a8b8caf05e7df17e6e749e57f6876ad99f5e5f", null ]
    ] ],
    [ "remap_addr0_t", "group___a_r_c_h___s_y_s_t_e_m.html#ga0b29367c2c771b17495e9eebd4e3c3a2", [
      [ "REMAP_ADDR0_TO_ROM", "group___a_r_c_h___s_y_s_t_e_m.html#gga0b29367c2c771b17495e9eebd4e3c3a2a49cfe983b7a503fada58385a996fe945", null ],
      [ "REMAP_ADDR0_TO_OTP", "group___a_r_c_h___s_y_s_t_e_m.html#gga0b29367c2c771b17495e9eebd4e3c3a2a6632523d0504645f7722709d6348f5d4", null ],
      [ "REMAP_ADDR0_TO_RAM1", "group___a_r_c_h___s_y_s_t_e_m.html#gga0b29367c2c771b17495e9eebd4e3c3a2a6fbfdf2f0bee13fe8114befa5ce0731f", null ],
      [ "REMAP_ADDR0_TO_RAM3", "group___a_r_c_h___s_y_s_t_e_m.html#gga0b29367c2c771b17495e9eebd4e3c3a2a3445af03568953c4d646a907d6f74933", null ]
    ] ],
    [ "sleep_state_t", "group___a_r_c_h___s_y_s_t_e_m.html#gadbadbf0b51f6342f6a48199d0583c04d", [
      [ "ARCH_SLEEP_OFF", "group___a_r_c_h___s_y_s_t_e_m.html#ggadbadbf0b51f6342f6a48199d0583c04daa246ab4642bb24ef4949a65b5b725f52", null ],
      [ "ARCH_EXT_SLEEP_ON", "group___a_r_c_h___s_y_s_t_e_m.html#ggadbadbf0b51f6342f6a48199d0583c04da6b59124ba3fe6d249e02509a7ae75bc2", null ],
      [ "ARCH_EXT_SLEEP_OTP_COPY_ON", "group___a_r_c_h___s_y_s_t_e_m.html#ggadbadbf0b51f6342f6a48199d0583c04daebe651e2eb9672787ed005f82729931e", null ]
    ] ],
    [ "arch_ble_ext_wakeup_get", "group___a_r_c_h___s_y_s_t_e_m.html#gafede6acbcf18a4afe7faa8c808a3ae39", null ],
    [ "arch_ble_ext_wakeup_off", "group___a_r_c_h___s_y_s_t_e_m.html#ga668c20225c755d57562f2a1cf55b9193", null ],
    [ "arch_ble_ext_wakeup_on", "group___a_r_c_h___s_y_s_t_e_m.html#ga7d56740e44054d55beadc58fb1143b27", null ],
    [ "arch_ble_force_wakeup", "group___a_r_c_h___s_y_s_t_e_m.html#gaa8232df27ad9a7a8290b2bc36d9d200d", null ],
    [ "arch_ble_metrics_get", "group___a_r_c_h___s_y_s_t_e_m.html#ga528bfb2b2987f2cb0f00f92dc701d92e", null ],
    [ "arch_ble_metrics_reset", "group___a_r_c_h___s_y_s_t_e_m.html#ga8f43baa11b1aeb2282490659f0205545", null ],
    [ "arch_disable_sleep", "group___a_r_c_h___s_y_s_t_e_m.html#gab4190b3d73c8de99f632dc5f6939f559", null ],
    [ "arch_force_active_mode", "group___a_r_c_h___s_y_s_t_e_m.html#ga2473104b650f57f1877e99d90916edbd", null ],
    [ "arch_get_sleep_mode", "group___a_r_c_h___s_y_s_t_e_m.html#ga134f39136e2ccedc0d96d839ea99e18e", null ],
    [ "arch_last_rwble_evt_get", "group___a_r_c_h___s_y_s_t_e_m.html#ga15936a06f1644be3ff70d3045e987f8d", null ],
    [ "arch_restore_sleep_mode", "group___a_r_c_h___s_y_s_t_e_m.html#gacfcb7f566b884bda32de19278305720a", null ],
    [ "arch_set_deep_sleep", "group___a_r_c_h___s_y_s_t_e_m.html#gaf222f9d99dddffe2979c1d7a92a6db00", null ],
    [ "arch_set_extended_sleep", "group___a_r_c_h___s_y_s_t_e_m.html#ga3b13151de1da9f64e7ff5fe6e359e757", null ],
    [ "arch_set_hibernation", "group___a_r_c_h___s_y_s_t_e_m.html#ga3fc064c606915371b5ef8bd39d84b9ad", null ],
    [ "arch_set_pxact_gpio", "group___a_r_c_h___s_y_s_t_e_m.html#gaf36df68fe0ea61bd014299f91f6879e7", null ],
    [ "arch_set_sleep_mode", "group___a_r_c_h___s_y_s_t_e_m.html#ga4a2fe3fe8f8028ab37adb4b7487c5874", null ],
    [ "arch_startup_sleep_delay_set", "group___a_r_c_h___s_y_s_t_e_m.html#gaa3c0b46c118c9293623c40f159b5c247", null ],
    [ "metrics", "group___a_r_c_h___s_y_s_t_e_m.html#gaad2442c50a44d837bb1259fafc338018", null ]
];