var app__suotar__task_8h =
[
    [ "app_suotar_process_handler", "app__suotar__task_8h.html#a680a5a4e23b6d29a777a31f8032565ec", null ]
];