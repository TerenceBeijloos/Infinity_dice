var app__prf__types_8h =
[
    [ "prf_func_uint8_t", "group___prf___types.html#gaff26530587a461636376901ec2f4a6ec", null ],
    [ "prf_func_validate_t", "group___prf___types.html#ga08ec9f7499fc7f4944fa7cbb7b3618be", null ],
    [ "prf_func_void_t", "group___prf___types.html#ga66dbf7c000590eed1fabcdd82c503de5", null ]
];