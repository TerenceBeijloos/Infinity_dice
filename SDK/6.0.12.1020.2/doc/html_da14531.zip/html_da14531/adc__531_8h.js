var adc__531_8h =
[
    [ "adc_interrupt_cb_t", "group___a_d_c.html#ga043bbec5c7365b329e2fa7d6e7c77f7d", null ],
    [ "adc_dma_channel_t", "group___a_d_c.html#ga40781c26ba2a3db008806c2fb43a6f0f", [
      [ "ADC_DMA_CHANNEL_01", "group___a_d_c.html#gga40781c26ba2a3db008806c2fb43a6f0faccf82ac12edafd12b228d5b99d7686f4", null ],
      [ "ADC_DMA_CHANNEL_23", "group___a_d_c.html#gga40781c26ba2a3db008806c2fb43a6f0faf99a904d1032cc4b99285b25384d2068", null ]
    ] ],
    [ "adc_input_attn_t", "group___a_d_c.html#ga18aff31452d090165d16e7dc0545a67f", [
      [ "ADC_INPUT_ATTN_NO", "group___a_d_c.html#gga18aff31452d090165d16e7dc0545a67fa19e5463d819181f867eae0cd01fb780b", null ],
      [ "ADC_INPUT_ATTN_2X", "group___a_d_c.html#gga18aff31452d090165d16e7dc0545a67fae50f1ee15bfa3f241e669a1e8aad46be", null ],
      [ "ADC_INPUT_ATTN_3X", "group___a_d_c.html#gga18aff31452d090165d16e7dc0545a67fa43f0b95e38f2f5f832a7921385eb6bd2", null ],
      [ "ADC_INPUT_ATTN_4X", "group___a_d_c.html#gga18aff31452d090165d16e7dc0545a67fafefe395aceb1b0d83555c82de036a575", null ]
    ] ],
    [ "adc_input_diff_t", "group___a_d_c.html#gad6ace048983511b17cfa070f4354f9d0", [
      [ "ADC_INPUT_DIFF_P0_1", "group___a_d_c.html#ggad6ace048983511b17cfa070f4354f9d0a5ca98ef373dd003c686a5df3a9967b38", null ],
      [ "ADC_INPUT_DIFF_P0_2", "group___a_d_c.html#ggad6ace048983511b17cfa070f4354f9d0a2220968136dd4da7cf34226c3fb5b0f0", null ],
      [ "ADC_INPUT_DIFF_P0_6", "group___a_d_c.html#ggad6ace048983511b17cfa070f4354f9d0a3e881a69f1d3009fd1ee516e01a735f9", null ],
      [ "ADC_INPUT_DIFF_P0_7", "group___a_d_c.html#ggad6ace048983511b17cfa070f4354f9d0a79924ac1fb420917923e0086df50596c", null ]
    ] ],
    [ "adc_input_mode_t", "group___a_d_c.html#ga8cd025ce4ccdf7ee0e601714fdbcf7ec", [
      [ "ADC_INPUT_MODE_DIFFERENTIAL", "group___a_d_c.html#gga8cd025ce4ccdf7ee0e601714fdbcf7eca04767d14c4a9f28c6ac92f16fa0a64b7", null ],
      [ "ADC_INPUT_MODE_SINGLE_ENDED", "group___a_d_c.html#gga8cd025ce4ccdf7ee0e601714fdbcf7eca74eaaf9f3db0340daa81a0804e75a93f", null ]
    ] ],
    [ "adc_input_se_t", "group___a_d_c.html#gac23bd0f898aa6001c8590474237c95b1", [
      [ "ADC_INPUT_SE_P0_1", "group___a_d_c.html#ggac23bd0f898aa6001c8590474237c95b1a338871223afc331e6773fe41d62d6e39", null ],
      [ "ADC_INPUT_SE_P0_2", "group___a_d_c.html#ggac23bd0f898aa6001c8590474237c95b1a4f1e4f2599df1e9f4528bf70a9bfb111", null ],
      [ "ADC_INPUT_SE_P0_6", "group___a_d_c.html#ggac23bd0f898aa6001c8590474237c95b1a7b9175f666565a93991d0e54bb9f0a3d", null ],
      [ "ADC_INPUT_SE_P0_7", "group___a_d_c.html#ggac23bd0f898aa6001c8590474237c95b1a9ba9968c2cc1220b5d2840f8a85e6dd6", null ],
      [ "ADC_INPUT_SE_TEMP_SENS", "group___a_d_c.html#ggac23bd0f898aa6001c8590474237c95b1a6912f2c3b60ff6b9154f10f4cc3990cc", null ],
      [ "ADC_INPUT_SE_VBAT_HIGH", "group___a_d_c.html#ggac23bd0f898aa6001c8590474237c95b1a0fbe587998f1fc1f17cf44dbe643ab8b", null ],
      [ "ADC_INPUT_SE_VBAT_LOW", "group___a_d_c.html#ggac23bd0f898aa6001c8590474237c95b1a3d2037d941ec95a2c6a656c0a382a028", null ],
      [ "ADC_INPUT_SE_VDD", "group___a_d_c.html#ggac23bd0f898aa6001c8590474237c95b1aa5dd75e916295fcf13aed08aebc3fe0a", null ]
    ] ],
    [ "adc_input_sh_cm_t", "group___a_d_c.html#ga3333eb3961609332b496234bf6866096", [
      [ "ADC_INPUT_SH_CM_1V25", "group___a_d_c.html#gga3333eb3961609332b496234bf6866096aefa6d256c1f09d7aea3d35df92fb9c66", null ],
      [ "ADC_INPUT_SH_CM_1V30", "group___a_d_c.html#gga3333eb3961609332b496234bf6866096a523b95bde227fa3d970a528ac305fd3f", null ],
      [ "ADC_INPUT_SH_CM_1V35", "group___a_d_c.html#gga3333eb3961609332b496234bf6866096a3505c69f17143adb861044dd42d48152", null ],
      [ "ADC_INPUT_SH_CM_1V40", "group___a_d_c.html#gga3333eb3961609332b496234bf6866096a781b5a6afe528a9ad519893f81e4b059", null ]
    ] ],
    [ "adc_input_sh_gain_t", "group___a_d_c.html#ga3d41c0bb10aa6d4bffb250629f1feafe", [
      [ "ADC_INPUT_SH_GAIN_2X", "group___a_d_c.html#gga3d41c0bb10aa6d4bffb250629f1feafea0e4e86ce16ba4e614341214cff894b5b", null ],
      [ "ADC_INPUT_SH_GAIN_2X25", "group___a_d_c.html#gga3d41c0bb10aa6d4bffb250629f1feafeaf1fbfd75fd42dfcc1cc7e877179cde80", null ]
    ] ],
    [ "adc_attn_config", "group___a_d_c.html#gaa42c841606b87227c8fc86334b376156", null ],
    [ "adc_chopper_disable", "group___a_d_c.html#ga992191de8cc62f3e9713d5531fc76ce8", null ],
    [ "adc_chopper_enable", "group___a_d_c.html#gacd0407f587a49dc6d2823e224c5b52a2", null ],
    [ "adc_clear_interrupt", "group___a_d_c.html#ga58d7dc6f5fdcede97de894d52a1fd77f", null ],
    [ "adc_continuous_disable", "group___a_d_c.html#gaa74270382fd4262d6c45da37b209cc44", null ],
    [ "adc_continuous_enable", "group___a_d_c.html#ga1b71af58491ec3aa55bb4d21c1df391a", null ],
    [ "adc_correct_sample", "group___a_d_c.html#gae0f49ae0c4f2b4b4d1c26b3f20d19f6b", null ],
    [ "adc_delay_set", "group___a_d_c.html#gaa1a73af7c4d2c299dc702ec8b391f10f", null ],
    [ "adc_dma_disable", "group___a_d_c.html#ga3ca5d1958582701c6412acc44581d817", null ],
    [ "adc_dma_enable", "group___a_d_c.html#ga5c81495d9873ae6c2285ddb76736b347", null ],
    [ "adc_get_diff_input", "group___a_d_c.html#ga80f8b6677c9f92648926db8b296d090f", null ],
    [ "adc_get_oversampling", "group___a_d_c.html#gab8de9711bd88d2352c456a56e3f4cf15", null ],
    [ "adc_get_se_input", "group___a_d_c.html#gaedd886e747a4cc4cefd5fbffc9d31dd1", null ],
    [ "adc_get_temp", "group___a_d_c.html#ga98e9aad2259c5e2f0086d62690e8b88f", null ],
    [ "adc_get_temp_async", "group___a_d_c.html#ga8cc7a616aac7920f311baa4ded7d4b73", null ],
    [ "adc_in_progress", "group___a_d_c.html#ga1f51a131ddc297669951bfa0eec6f5ab", null ],
    [ "adc_input_shift_config", "group___a_d_c.html#ga6b0252775202ca8fe3a24ce54ab95608", null ],
    [ "adc_input_shift_disable", "group___a_d_c.html#gaa77d66ddc4e72ca73e7867d51452dfb1", null ],
    [ "adc_input_shift_enable", "group___a_d_c.html#gaf9eb394a43826b00893ced6340ccdcb1", null ],
    [ "adc_ldo_const_current_disable", "group___a_d_c.html#gafbb129affad453295ecfdd613ef6ac23", null ],
    [ "adc_ldo_const_current_enable", "group___a_d_c.html#ga8db935bff2b8a92fc3b236e763988b22", null ],
    [ "adc_set_interval", "group___a_d_c.html#ga0119c4ca10309b033710b908ffa178d9", null ],
    [ "adc_set_oversampling", "group___a_d_c.html#ga5b563f7a97281dad7aa0739f2fb6fed2", null ],
    [ "adc_set_sample_time", "group___a_d_c.html#ga5e67b6908b5b54c23b62cf75dbd966fe", null ],
    [ "adc_start", "group___a_d_c.html#gaf5ce9946f045a1396ac1a147252a3e76", null ],
    [ "adc_temp_sensor_disable", "group___a_d_c.html#gaa4c4548bb2182a0bfac6c8d201327fec", null ],
    [ "adc_temp_sensor_enable", "group___a_d_c.html#ga55a73030e3815b72fc786105e9ffed95", null ]
];