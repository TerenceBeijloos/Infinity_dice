var app__bass__task_8h =
[
    [ "app_bass_process_handler", "app__bass__task_8h.html#a4414aa917ec222b119e072a3e87d77e8", null ],
    [ "bat_led_pin", "app__bass__task_8h.html#a0f78e69f5e77bfa002dcca1023e86110", null ],
    [ "bat_led_port", "app__bass__task_8h.html#a76433311e17cae8ef1359da3d927e920", null ],
    [ "bat_lvl_alert_used", "app__bass__task_8h.html#a2656241d4ac7f973dfad0a7d0be09313", null ],
    [ "bat_poll_timeout", "app__bass__task_8h.html#a66136d4d67490269f23688bae848b53e", null ]
];