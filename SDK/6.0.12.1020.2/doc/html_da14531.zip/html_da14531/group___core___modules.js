var group___core___modules =
[
    [ "Serial Logging", "group___arch__console.html", "group___arch__console" ],
    [ "Crypto", "group___crypto.html", "group___crypto" ],
    [ "Real Time Kernel", "group___k_e_r_n_e_l.html", "group___k_e_r_n_e_l" ],
    [ "NVDS", "group___n_v_d_s.html", "group___n_v_d_s" ],
    [ "RF", "group___r_f.html", "group___r_f" ]
];