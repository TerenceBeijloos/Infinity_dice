var arch__wdg_8h =
[
    [ "USE_WDOG", "group___a_r_c_h___w_d_g.html#ga93ad6e759d5012b871aa882acc3e4479", null ],
    [ "WATCHDOG_DEFAULT_PERIOD", "group___a_r_c_h___w_d_g.html#ga2f8bdb110935da3518c92c0557d6d258", null ],
    [ "wdg_freeze", "group___a_r_c_h___w_d_g.html#gadcfffde3f504bf5155d9ba4b624af6ae", null ],
    [ "wdg_init", "group___a_r_c_h___w_d_g.html#ga9cf682eb46b53f1644a28cfcfb4cd741", null ],
    [ "wdg_reload", "group___a_r_c_h___w_d_g.html#gad84173477318d7427f078ff4b880dea2", null ],
    [ "wdg_resume", "group___a_r_c_h___w_d_g.html#gaf56dec376692e4bac3dba27e33b00367", null ]
];