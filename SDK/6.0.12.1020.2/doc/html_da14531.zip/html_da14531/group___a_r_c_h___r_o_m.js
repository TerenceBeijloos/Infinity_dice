var group___a_r_c_h___r_o_m =
[
    [ "arch_rom.h", "arch__rom_8h.html", null ],
    [ "h4tl_out_of_sync_tag", "structh4tl__out__of__sync__tag.html", [
      [ "byte", "structh4tl__out__of__sync__tag.html#ab18d9b3fbaee7d5124514fc0493005e6", null ],
      [ "index", "structh4tl__out__of__sync__tag.html#a88c018fbaec77afbbffe10e899ad8690", null ]
    ] ],
    [ "h4tl_env_tag", "structh4tl__env__tag.html", [
      [ "curr_hdr_buff", "structh4tl__env__tag.html#a8f0d2357d90661005fc4d7ceefd68dc8", null ],
      [ "curr_payl_buff", "structh4tl__env__tag.html#a73920fa0bb23e9c4bd7b9984f8e9d102", null ],
      [ "ext_if", "structh4tl__env__tag.html#ad182df7a773f5a748a4bb0f53a4d125e", null ],
      [ "out_of_sync", "structh4tl__env__tag.html#a6e922fe7ba603442fcc44aeb971f77d0", null ],
      [ "rx_state", "structh4tl__env__tag.html#a7e3356c021a8e2c827655a89c455c21b", null ],
      [ "rx_type", "structh4tl__env__tag.html#a0abcf914e6c1b3093476279bc7313001", null ],
      [ "tx_callback", "structh4tl__env__tag.html#af4318f3ad69b66ab9cd41988f0d1bd46", null ],
      [ "tx_state", "structh4tl__env__tag.html#a66b341e39f6d8607d955852eebd63018", null ]
    ] ],
    [ "MAX_HEADER_SIZE", "group___a_r_c_h___r_o_m.html#gab4ef65077affc5d61e2b41556d4b8387", null ],
    [ "H4TL", "group___a_r_c_h___r_o_m.html#gae906a53899c8eed244d88940b0c9b4db", [
      [ "H4TL_STATE_TX_ONGOING", "group___a_r_c_h___r_o_m.html#ggae906a53899c8eed244d88940b0c9b4dbaed612105745dcc4192b88c1ced42f14d", null ],
      [ "H4TL_STATE_TX_IDLE", "group___a_r_c_h___r_o_m.html#ggae906a53899c8eed244d88940b0c9b4dba0ccb207f110ce5aa3b36fc714a610098", null ]
    ] ],
    [ "H4TL_STATE_RX", "group___a_r_c_h___r_o_m.html#ga925c891fd57ba111049052d45d3da474", [
      [ "H4TL_STATE_RX_START", "group___a_r_c_h___r_o_m.html#gga925c891fd57ba111049052d45d3da474a0bb225209dc9822deecb34bf96a3d8c0", null ],
      [ "H4TL_STATE_RX_HDR", "group___a_r_c_h___r_o_m.html#gga925c891fd57ba111049052d45d3da474a43613b27e99ccfde18a33662a67b3756", null ],
      [ "H4TL_STATE_RX_PAYL", "group___a_r_c_h___r_o_m.html#gga925c891fd57ba111049052d45d3da474a3d17a04856c0650e9c3c6cd7e93946c2", null ],
      [ "H4TL_STATE_RX_OUT_OF_SYNC", "group___a_r_c_h___r_o_m.html#gga925c891fd57ba111049052d45d3da474a0d34e3d41d7c4dd3a3e64732c369a0b8", null ]
    ] ],
    [ "arch_rom_init", "group___a_r_c_h___r_o_m.html#ga62608f45677872f5e77862d4e9a8a4bc", null ],
    [ "gap_cfg_user_var_struct", "group___a_r_c_h___r_o_m.html#ga80a7ccb9501a6ba723fa2ad2b0d2a34c", null ],
    [ "h4tl_env", "group___a_r_c_h___r_o_m.html#ga00e064a2de103b5c8483b2df9ffd8334", null ],
    [ "hci_cmd_desc_root_tab", "group___a_r_c_h___r_o_m.html#ga4f88707b54e80efd6f5ed4f4b9d3725a", null ],
    [ "length_exchange_needed", "group___a_r_c_h___r_o_m.html#ga9591f807956b8998020104b06f03d132", null ],
    [ "rom_cfg_table", "group___a_r_c_h___r_o_m.html#ga9e9a648f760369aac567b0bee2667a20", null ],
    [ "rom_cfg_table_var", "group___a_r_c_h___r_o_m.html#ga97d1d409cb84f7b68a1040573c59c30e", null ],
    [ "rom_func_addr_table", "group___a_r_c_h___r_o_m.html#gacd607e13707a17adf2cee6770280cb1b", null ],
    [ "rom_func_addr_table_var", "group___a_r_c_h___r_o_m.html#ga3c719ae8f2de734383a8c5b73ec36474", null ],
    [ "rom_hci_cmd_desc_root_tab", "group___a_r_c_h___r_o_m.html#ga01294a2bc2d09203ec057e3658f02cae", null ],
    [ "use_h4tl", "group___a_r_c_h___r_o_m.html#gaaa7d9737d087453e984ec4d1afe1c240", null ]
];