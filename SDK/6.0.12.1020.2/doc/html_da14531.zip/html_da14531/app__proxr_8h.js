var app__proxr_8h =
[
    [ "app_proxr_alert_start", "group___p_r_o_x_r.html#gaeee285e80c7d25f650b49b2a97305ea8", null ],
    [ "app_proxr_alert_stop", "group___p_r_o_x_r.html#ga14b42144e227c6694f107a43815accdb", null ],
    [ "app_proxr_create_db", "group___p_r_o_x_r.html#ga7d2e57099dd49fc78d5d41e0a2bd4e13", null ],
    [ "app_proxr_init", "group___p_r_o_x_r.html#ga51ebefc205e8827ab254f79a8c8afeb3", null ],
    [ "app_proxr_port_reinit", "group___p_r_o_x_r.html#ga72579aa1537e14295043954ade7312fa", null ],
    [ "default_proxr_alert_ind_handler", "group___p_r_o_x_r.html#gae4eb73a273d205b71fc6706e42851c61", null ],
    [ "alert_state", "group___p_r_o_x_r.html#ga19bc79f37c490fb81ee2b31a561dd191", null ]
];