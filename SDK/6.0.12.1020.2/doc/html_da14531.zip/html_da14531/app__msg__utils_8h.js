var app__msg__utils_8h =
[
    [ "app_check_BLE_active", "group___msg___utils.html#ga5e5357406667417d8c275407122640c1", null ],
    [ "app_msg_send", "group___msg___utils.html#gaf73e85874771db18678764b8c26e7adb", null ],
    [ "app_msg_send_wakeup_ble", "group___msg___utils.html#ga52ea0e2af7c6d3e63a8393bae9455413", null ]
];