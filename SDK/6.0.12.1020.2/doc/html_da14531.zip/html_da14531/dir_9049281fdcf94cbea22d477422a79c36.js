var dir_9049281fdcf94cbea22d477422a79c36 =
[
    [ "arch_ram.h", "arch__ram_8h.html", "arch__ram_8h" ],
    [ "arch_rom.h", "arch__rom_8h.html", "arch__rom_8h" ],
    [ "arch_system.h", "arch__system_8h.html", "arch__system_8h" ],
    [ "arch_wdg.h", "arch__wdg_8h.html", "arch__wdg_8h" ]
];