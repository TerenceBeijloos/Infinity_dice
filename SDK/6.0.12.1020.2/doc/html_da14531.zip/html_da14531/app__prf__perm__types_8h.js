var app__prf__perm__types_8h =
[
    [ "PRFS_TASK_ID_MAX", "group___prf___perm___types.html#ga4266c888679c8d777e1bd9705ae37a41", null ],
    [ "app_prf_srv_perm_t", "group___prf___perm___types.html#gad84ca9844db66b881d6116ec24e1bea2", null ],
    [ "app_prf_srv_sec_t", "group___prf___perm___types.html#gaf2badcf0b6c2d7c0f43630287ecf6ab3", null ],
    [ "app_prf_srv_perm", "group___prf___perm___types.html#ga643ca59709fbe5330932c85f603e531c", [
      [ "SRV_PERM_DISABLE", "group___prf___perm___types.html#gga643ca59709fbe5330932c85f603e531cae57d4673165047bfd17299b8c6b61cba", null ],
      [ "SRV_PERM_ENABLE", "group___prf___perm___types.html#gga643ca59709fbe5330932c85f603e531ca9773e249e4ee173e02a3ca68e4183039", null ],
      [ "SRV_PERM_UNAUTH", "group___prf___perm___types.html#gga643ca59709fbe5330932c85f603e531ca2e2045b11a31dd6a33f60afabbc0e80d", null ],
      [ "SRV_PERM_AUTH", "group___prf___perm___types.html#gga643ca59709fbe5330932c85f603e531ca4b8d30b50605d48236f3231753971896", null ],
      [ "SRV_PERM_SECURE", "group___prf___perm___types.html#gga643ca59709fbe5330932c85f603e531ca20eb379fb4d1fbda86f6ac6ddcaf5d8b", null ]
    ] ],
    [ "app_set_prf_srv_perm", "group___prf___perm___types.html#gaee472f8eb751ef31f2bfa277af6ea717", null ],
    [ "get_user_prf_srv_perm", "group___prf___perm___types.html#gac61dc07f24ac8806f3f575f13cb6b01c", null ],
    [ "prf_init_srv_perm", "group___prf___perm___types.html#gaa618ae6d780f6651293e59177186747c", null ],
    [ "app_prf_srv_perm", "group___prf___perm___types.html#ga705663221a3be3d02c3868394b66a7b3", null ]
];