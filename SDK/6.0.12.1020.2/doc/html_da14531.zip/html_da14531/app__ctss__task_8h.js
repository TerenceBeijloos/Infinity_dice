var app__ctss__task_8h =
[
    [ "APP_CTS_IDX_MAX", "app__ctss__task_8h.html#aae9fc060c0682f97aa5cf5fd58e80ed7", null ],
    [ "app_ctss_process_handler", "app__ctss__task_8h.html#a6a29bf646ccc2a3eb8c99f6c8d5bd1cb", null ]
];