var dir_4a3f43c839d30a4863a3f5f60e4e3af2 =
[
    [ "spi.h", "spi_8h.html", "spi_8h" ],
    [ "spi_531.h", "spi__531_8h.html", "spi__531_8h" ]
];