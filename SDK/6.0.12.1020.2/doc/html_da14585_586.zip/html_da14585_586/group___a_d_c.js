var group___a_d_c =
[
    [ "adc.h", "adc_8h.html", null ],
    [ "adc_58x.h", "adc__58x_8h.html", null ],
    [ "adc_config_t", "structadc__config__t.html", [
      [ "attn", "structadc__config__t.html#ad72ad991a9770788609d02007fe615ae", null ],
      [ "input", "structadc__config__t.html#aa555a681f732e75408324928d60d2ddf", null ],
      [ "mode", "structadc__config__t.html#ab0901085a5e0f05cae9dca993e91af63", null ],
      [ "sign", "structadc__config__t.html#afd882c6853d84c72cb3e7c2a81146ac1", null ]
    ] ],
    [ "ADC_TIMEOUT", "group___a_d_c.html#ga7825c3897a78747566304d9b44f087d2", null ],
    [ "adc_interrupt_cb_t", "group___a_d_c.html#ga043bbec5c7365b329e2fa7d6e7c77f7d", null ],
    [ "adc_input_diff_t", "group___a_d_c.html#gad6ace048983511b17cfa070f4354f9d0", [
      [ "ADC_INPUT_DIFF_P0_0_P0_1", "group___a_d_c.html#ggad6ace048983511b17cfa070f4354f9d0af9f1451943fea844b6549192c79ec95b", null ],
      [ "ADC_INPUT_DIFF_P0_2_P0_3", "group___a_d_c.html#ggad6ace048983511b17cfa070f4354f9d0ae1b9353d482b639ffc1f7b3c80961b5f", null ]
    ] ],
    [ "adc_input_mode_t", "group___a_d_c.html#ga8cd025ce4ccdf7ee0e601714fdbcf7ec", [
      [ "ADC_INPUT_MODE_DIFFERENTIAL", "group___a_d_c.html#gga8cd025ce4ccdf7ee0e601714fdbcf7eca04767d14c4a9f28c6ac92f16fa0a64b7", null ],
      [ "ADC_INPUT_MODE_SINGLE_ENDED", "group___a_d_c.html#gga8cd025ce4ccdf7ee0e601714fdbcf7eca74eaaf9f3db0340daa81a0804e75a93f", null ]
    ] ],
    [ "adc_input_se_t", "group___a_d_c.html#gac23bd0f898aa6001c8590474237c95b1", [
      [ "ADC_INPUT_SE_P0_0", "group___a_d_c.html#ggac23bd0f898aa6001c8590474237c95b1a883bec73d13fafc1529d348479d5e5b0", null ],
      [ "ADC_INPUT_SE_P0_1", "group___a_d_c.html#ggac23bd0f898aa6001c8590474237c95b1a338871223afc331e6773fe41d62d6e39", null ],
      [ "ADC_INPUT_SE_P0_2", "group___a_d_c.html#ggac23bd0f898aa6001c8590474237c95b1a4f1e4f2599df1e9f4528bf70a9bfb111", null ],
      [ "ADC_INPUT_SE_P0_3", "group___a_d_c.html#ggac23bd0f898aa6001c8590474237c95b1a5658d23645d0f79f94acab800f7d0cd1", null ],
      [ "ADC_INPUT_SE_AVS", "group___a_d_c.html#ggac23bd0f898aa6001c8590474237c95b1a39619ac0ea99e0fca0c6cd4578834f7b", null ],
      [ "ADC_INPUT_SE_VDD_REF", "group___a_d_c.html#ggac23bd0f898aa6001c8590474237c95b1a667ce0a1b1bc0884e90f45528a1fa270", null ],
      [ "ADC_INPUT_SE_VDD_RTT", "group___a_d_c.html#ggac23bd0f898aa6001c8590474237c95b1adb8889707031a188ec88749fd6bbe90f", null ],
      [ "ADC_INPUT_SE_VBAT3V", "group___a_d_c.html#ggac23bd0f898aa6001c8590474237c95b1a883fb5f55a8f54faa603c30b8bac5ae1", null ],
      [ "ADC_INPUT_SE_VDCDC", "group___a_d_c.html#ggac23bd0f898aa6001c8590474237c95b1ae0b532e2eed935198a2e01fbbdbd80e5", null ],
      [ "ADC_INPUT_SE_VBAT1V", "group___a_d_c.html#ggac23bd0f898aa6001c8590474237c95b1adff4d2e7f030b6cc589fa031dd36aa15", null ]
    ] ],
    [ "adc_disable", "group___a_d_c.html#ga3b4b977d0665b5346849f3b892ac5106", null ],
    [ "adc_enable", "group___a_d_c.html#ga3afdea3b7c9b91013c270f1a1a669782", null ],
    [ "adc_get_input_mode", "group___a_d_c.html#ga974d2e690cf831c6afb176937e97e6cd", null ],
    [ "adc_get_offset_negative", "group___a_d_c.html#ga3ec4ef91b9a94fc21cb8df6ccda116b2", null ],
    [ "adc_get_offset_positive", "group___a_d_c.html#ga470447cd10b542f52ce6fe9ad96bd963", null ],
    [ "adc_get_sample", "group___a_d_c.html#ga9dad19596069f4ded0b824f8ddce49b2", null ],
    [ "adc_get_vbat_sample", "group___a_d_c.html#ga128d517dad92de323e2ecb32e445194c", null ],
    [ "adc_init", "group___a_d_c.html#ga5397d7276f8f90c59cf0842e0515df9a", null ],
    [ "adc_input_mute", "group___a_d_c.html#gaafe746f03498d70f05d32deb16ee32cf", null ],
    [ "adc_input_unmute", "group___a_d_c.html#ga25581bb4dcf352d39d3dd2d17907fa75", null ],
    [ "adc_offset_calibrate", "group___a_d_c.html#ga5d52ae4e1729fa0ae39b00ee574022a1", null ],
    [ "adc_register_interrupt", "group___a_d_c.html#ga5230388ae68ade677e61d9f9d1923b99", null ],
    [ "adc_reset", "group___a_d_c.html#ga81badb55f6183f8680189f895d510743", null ],
    [ "adc_set_diff_input", "group___a_d_c.html#ga99f67baeb8a0c7a8349b6689cb0c5288", null ],
    [ "adc_set_input_mode", "group___a_d_c.html#ga30c989aacaf83411a5f0dc10e39efa06", null ],
    [ "adc_set_offset_negative", "group___a_d_c.html#ga8db6b71645917ceb03a51764c7a938f1", null ],
    [ "adc_set_offset_positive", "group___a_d_c.html#gad050e20aef20005aded623bbfd9d8f62", null ],
    [ "adc_set_se_input", "group___a_d_c.html#ga5853f9435564ddc009e7cd0d0497d474", null ],
    [ "adc_sign_change_disable", "group___a_d_c.html#ga4edefa9e96b39df064fac5a84e8bfaad", null ],
    [ "adc_sign_change_enable", "group___a_d_c.html#ga96befacf63b49bbbb9c5b2e792171d79", null ],
    [ "adc_unregister_interrupt", "group___a_d_c.html#gaa7b713e36b7f5676a4f149b6b2c4f3f3", null ]
];