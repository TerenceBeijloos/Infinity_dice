var group___c_t_s_s =
[
    [ "app_ctss.h", "app__ctss_8h.html", null ],
    [ "app_ctss_cb", "structapp__ctss__cb.html", [
      [ "on_cur_time_notified", "structapp__ctss__cb.html#ace1c613fd15eabc2c454a686408fa0e4", null ],
      [ "on_cur_time_read_req", "structapp__ctss__cb.html#a23ff5f71d386149bf46b0b64b4fc9319", null ],
      [ "on_cur_time_write_req", "structapp__ctss__cb.html#ab3c23a86d3589087595f83df79c6fc09", null ],
      [ "on_loc_time_info_write_req", "structapp__ctss__cb.html#aba67e15d76a7c3abb29f96e96796fce8", null ],
      [ "on_ref_time_info_read_req", "structapp__ctss__cb.html#a1d859f0e1fded23b5bb41d53b4252a0a", null ]
    ] ],
    [ "app_ctss_create_db", "group___c_t_s_s.html#gab1b5bf63a7b5747a57d3edea0598d0bc", null ],
    [ "app_ctss_init", "group___c_t_s_s.html#ga1ccf490d8b882a478b1a8ffdc2ae27f1", null ],
    [ "app_ctss_notify_current_time", "group___c_t_s_s.html#ga79023ffab2cda029e213f474d3c5c940", null ]
];