var app__entry__point_8h =
[
    [ "KE_FIND_RELATED_TASK", "group___entry___point.html#ga2ea4b5db4f501166fa18d9b0569f0104", null ],
    [ "catch_rest_event_func_t", "group___entry___point.html#gac05aaa74a9a28606d7f0447441f9e102", null ],
    [ "process_event_func_t", "group___entry___point.html#gac2f4853fde78f0cf6ae5629904aac012", null ],
    [ "process_event_response", "group___entry___point.html#ga5c41a445d11cbb6e27cc0a1ebff7e7e9", [
      [ "PR_EVENT_HANDLED", "group___entry___point.html#gga5c41a445d11cbb6e27cc0a1ebff7e7e9ab6b01ada97c69aa0e4a6cf7fcc42a622", null ],
      [ "PR_EVENT_UNHANDLED", "group___entry___point.html#gga5c41a445d11cbb6e27cc0a1ebff7e7e9a3f4a65f7f380af76b414bf5b7274da73", null ]
    ] ],
    [ "app_entry_point_handler", "group___entry___point.html#gaf2401148c7f8fffe0e8f401579857027", null ],
    [ "app_std_process_event", "group___entry___point.html#ga48ac78647888cdb05da47f5dc12fcb40", null ]
];