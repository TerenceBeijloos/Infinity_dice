var chacha20_8h =
[
    [ "csprng_get_next_uint32", "group___rand.html#gaf0526f3becc085ddc94930b03f306c17", null ],
    [ "csprng_seed", "group___rand.html#ga3bb0558cad08023912c4e9b9434b8da8", null ]
];