var dma_8h =
[
    [ "DMA", "group___d_m_a.html#gaea16041b87e0c077b0cacb7b6db629fe", null ],
    [ "DMA_CH_GET", "group___d_m_a.html#gae7025d0670c8a0750ca3355f13c967be", null ],
    [ "DMA_CHANNEL_MAX", "group___d_m_a.html#ga66c53d852fd0699897e33bde3118f09c", null ],
    [ "DMA_ID_GET", "group___d_m_a.html#ga51786186d7f658250a404bd6bfccc64e", null ],
    [ "dma_cb_t", "group___d_m_a.html#gaaf2cf776daf231f8a9239c82d0533f2c", null ],
    [ "DMA_BW_CFG", "group___d_m_a.html#gac8f2cdc0ea6fd35b13c287a06d13297e", [
      [ "DMA_BW_BYTE", "group___d_m_a.html#ggac8f2cdc0ea6fd35b13c287a06d13297eaf648997f3ea7c0bec4f9a5ee116588ae", null ],
      [ "DMA_BW_HALFWORD", "group___d_m_a.html#ggac8f2cdc0ea6fd35b13c287a06d13297eaf4330bea81933d78c9ebf7fab015fe2c", null ],
      [ "DMA_BW_WORD", "group___d_m_a.html#ggac8f2cdc0ea6fd35b13c287a06d13297ea3559ba5f200edc662629550b14682594", null ]
    ] ],
    [ "DMA_DREQ_CFG", "group___d_m_a.html#ga40ca0cafb80876b1a8d2136b92c7feba", [
      [ "DMA_DREQ_START", "group___d_m_a.html#gga40ca0cafb80876b1a8d2136b92c7febaa6d5cc19d5cff92b57147723444ab5c99", null ],
      [ "DMA_DREQ_TRIGGERED", "group___d_m_a.html#gga40ca0cafb80876b1a8d2136b92c7febaa16b83ae5b5732549689ef76469854277", null ]
    ] ],
    [ "DMA_ID", "group___d_m_a.html#ga322d21ecbd706be7daa82cf4b9a3ec38", [
      [ "DMA_CHANNEL_0", "group___d_m_a.html#gga322d21ecbd706be7daa82cf4b9a3ec38a8b3e2f577feb0b99e85c1b98f862aa97", null ],
      [ "DMA_CHANNEL_1", "group___d_m_a.html#gga322d21ecbd706be7daa82cf4b9a3ec38aadb7b1e8ed33387dafc273a7c6f158e1", null ],
      [ "DMA_CHANNEL_2", "group___d_m_a.html#gga322d21ecbd706be7daa82cf4b9a3ec38ab8db49e1e7a26f446582c8a03b484f28", null ],
      [ "DMA_CHANNEL_3", "group___d_m_a.html#gga322d21ecbd706be7daa82cf4b9a3ec38ab873295112ed9b07822ffa404aafa057", null ]
    ] ],
    [ "DMA_IDLE_CFG", "group___d_m_a.html#ga14b1f0be0d0b1fbf811507575397f613", [
      [ "DMA_IDLE_BLOCKING_MODE", "group___d_m_a.html#gga14b1f0be0d0b1fbf811507575397f613a9407d5e83a8b7a44b395e57542ccd585", null ],
      [ "DMA_IDLE_INTERRUPTING_MODE", "group___d_m_a.html#gga14b1f0be0d0b1fbf811507575397f613a2b356009b7327d94b4a0f9c305c7ed6f", null ]
    ] ],
    [ "DMA_INC_CFG", "group___d_m_a.html#ga77ea52c03c57dc122edc7ccc1797e023", [
      [ "DMA_INC_FALSE", "group___d_m_a.html#gga77ea52c03c57dc122edc7ccc1797e023a6fefa32fadb2e4d8e27f31a468b6f932", null ],
      [ "DMA_INC_TRUE", "group___d_m_a.html#gga77ea52c03c57dc122edc7ccc1797e023ac34ff7b807c6b8a9360742820237cd5a", null ]
    ] ],
    [ "DMA_INIT_CFG", "group___d_m_a.html#ga3a4b6ce3340dc24c140ef9bbbd3b35ff", [
      [ "DMA_INIT_AX_BX_AY_BY", "group___d_m_a.html#gga3a4b6ce3340dc24c140ef9bbbd3b35ffa550ad9ec39879d265eed41072f94538a", null ],
      [ "DMA_INIT_AX_BX_BY", "group___d_m_a.html#gga3a4b6ce3340dc24c140ef9bbbd3b35ffa0121eef1250302708583e71342213ccb", null ]
    ] ],
    [ "DMA_IRQ_CFG", "group___d_m_a.html#ga66a52c2902c3bb16a50292f53641618f", [
      [ "DMA_IRQ_STATE_DISABLED", "group___d_m_a.html#gga66a52c2902c3bb16a50292f53641618fa6814e4eb2804985ae66ceb59fe7a182c", null ],
      [ "DMA_IRQ_STATE_ENABLED", "group___d_m_a.html#gga66a52c2902c3bb16a50292f53641618fa93027dd7d7b5231573dc69af9aa384a3", null ]
    ] ],
    [ "DMA_MODE_CFG", "group___d_m_a.html#gae7b1c01e2dd6561278da5d05ee1d9974", [
      [ "DMA_MODE_NORMAL", "group___d_m_a.html#ggae7b1c01e2dd6561278da5d05ee1d9974a712d4572ce85937168ea1e885ecbf763", null ],
      [ "DMA_MODE_CIRCULAR", "group___d_m_a.html#ggae7b1c01e2dd6561278da5d05ee1d9974a0541b0c83083cd2c18ba14900f338368", null ]
    ] ],
    [ "DMA_PRIO_CFG", "group___d_m_a.html#ga14e6b305b1ac96b5cb5262931642d1fd", [
      [ "DMA_PRIO_0", "group___d_m_a.html#gga14e6b305b1ac96b5cb5262931642d1fdaba1696511a539c90b6eff166f774c01f", null ],
      [ "DMA_PRIO_1", "group___d_m_a.html#gga14e6b305b1ac96b5cb5262931642d1fda283ae579bacde4a8bbcb68a4045fe200", null ],
      [ "DMA_PRIO_2", "group___d_m_a.html#gga14e6b305b1ac96b5cb5262931642d1fdad314f264a694a4be8868d1dd320f7b86", null ],
      [ "DMA_PRIO_3", "group___d_m_a.html#gga14e6b305b1ac96b5cb5262931642d1fda35aecd51a3fd0317c6e8591edc929edc", null ],
      [ "DMA_PRIO_4", "group___d_m_a.html#gga14e6b305b1ac96b5cb5262931642d1fda9b2f7e8285a67338aa6d3e1b25be43f9", null ],
      [ "DMA_PRIO_5", "group___d_m_a.html#gga14e6b305b1ac96b5cb5262931642d1fda041531667a2ae37ae36b80c149ce3dd5", null ],
      [ "DMA_PRIO_6", "group___d_m_a.html#gga14e6b305b1ac96b5cb5262931642d1fdad93634c3d6fe4bb74e965bdbd384b23e", null ],
      [ "DMA_PRIO_7", "group___d_m_a.html#gga14e6b305b1ac96b5cb5262931642d1fdacaa0ca9fb1b4cc8025b93a5239529071", null ]
    ] ],
    [ "DMA_SENSE_CFG", "group___d_m_a.html#ga3264ed48921c6f9af67dc3b447afead7", [
      [ "DMA_SENSE_LEVEL_SENSITIVE", "group___d_m_a.html#gga3264ed48921c6f9af67dc3b447afead7ade178165cf084ee7546d117513b77b24", null ],
      [ "DMA_SENSE_POSITIVE_EDGE_SENSITIVE", "group___d_m_a.html#gga3264ed48921c6f9af67dc3b447afead7ad0f3fb0a30858fb7671c262d84cbe7b1", null ]
    ] ],
    [ "DMA_STATE_CFG", "group___d_m_a.html#gac4dccdfdabaf5155dbbea8443be63ac4", [
      [ "DMA_STATE_DISABLED", "group___d_m_a.html#ggac4dccdfdabaf5155dbbea8443be63ac4a5880e500ed8266b7b95b1da92b3240f7", null ],
      [ "DMA_STATE_ENABLED", "group___d_m_a.html#ggac4dccdfdabaf5155dbbea8443be63ac4a63ebe2f844cb37251eca57340ac25204", null ]
    ] ],
    [ "DMA_TRIG_CFG", "group___d_m_a.html#ga7bfc79c7718aff1446ca022240a4b366", [
      [ "DMA_TRIG_SPI_RXTX", "group___d_m_a.html#gga7bfc79c7718aff1446ca022240a4b366a201a43c33f4bff26f788ba4f12264750", null ],
      [ "DMA_TRIG_UART_RXTX", "group___d_m_a.html#gga7bfc79c7718aff1446ca022240a4b366ab0107df3fc9a166fbc98ef3eea51d6df", null ],
      [ "DMA_TRIG_UART2_RXTX", "group___d_m_a.html#gga7bfc79c7718aff1446ca022240a4b366a2006f76fef8aa6955e2934d9fd86326a", null ],
      [ "DMA_TRIG_I2C_RXTX", "group___d_m_a.html#gga7bfc79c7718aff1446ca022240a4b366a189ea1f619163b1d5aaa6cd4f76cf134", null ],
      [ "DMA_TRIG_NONE", "group___d_m_a.html#gga7bfc79c7718aff1446ca022240a4b366a42bbee3aee8f4750523e1554ca603ef5", null ]
    ] ],
    [ "dma_channel_active", "group___d_m_a.html#ga4d5e6af7491aa17d2c38c9045cb0a4b2", null ],
    [ "dma_channel_cancel", "group___d_m_a.html#ga9454c892891a36f414e16ac0a5a23e56", null ],
    [ "dma_channel_start", "group___d_m_a.html#ga9d1535d6c4ebbee48deba55872e0a0a8", null ],
    [ "dma_channel_stop", "group___d_m_a.html#ga631ff67c16f2d40faaeff48142a226d7", null ],
    [ "dma_clear_ctrl_reg", "group___d_m_a.html#ga9edce2d2637b210afbafd9a6b59a1426", null ],
    [ "dma_clear_int_reg", "group___d_m_a.html#ga9f6c7d11e435bd00bcaba0683879c245", null ],
    [ "dma_freeze", "group___d_m_a.html#gaaac6b7ba2625545e45042c6a90e4290f", null ],
    [ "dma_get_channel_state", "group___d_m_a.html#gaebda4b2033c4c1715d5aed85d22ef75f", null ],
    [ "dma_get_ctrl_reg", "group___d_m_a.html#ga1fe25822f448b56f9e15cff89d5242b2", null ],
    [ "dma_get_idx", "group___d_m_a.html#ga52596b2c328fd949595dd8e0825c8451", null ],
    [ "dma_get_int", "group___d_m_a.html#ga86c59d46af12113e75d701d5b649ef46", null ],
    [ "dma_get_int_status", "group___d_m_a.html#ga585cc0934b20f9da91a1d63381823922", null ],
    [ "dma_get_len", "group___d_m_a.html#ga673a280dc070385a798cfbf30e1ac44b", null ],
    [ "dma_get_req_mux_ch01", "group___d_m_a.html#gaf2efc9ef9eeeb331622d932ab4e457e2", null ],
    [ "dma_get_req_mux_ch23", "group___d_m_a.html#ga4e265741c749a4c427fefe06b4e2174f", null ],
    [ "dma_initialize", "group___d_m_a.html#gaca8e2cdfe81c47b8489f2a865e9555b6", null ],
    [ "dma_register_callback", "group___d_m_a.html#ga06a08520c51d619f9bd1996c57bd3afd", null ],
    [ "dma_set_ainc", "group___d_m_a.html#ga68e77ee6c84bedbfcd668641ce572aae", null ],
    [ "dma_set_binc", "group___d_m_a.html#gac0eba000e613568fe63b156b18676859", null ],
    [ "dma_set_bw", "group___d_m_a.html#gaf524c52fa863eaefb5e0030c86096b76", null ],
    [ "dma_set_circular", "group___d_m_a.html#ga3a5f6667d01d65d0e0f1cd4ae174270c", null ],
    [ "dma_set_ctrl_reg", "group___d_m_a.html#gae732754ac99a3668e9d43fbcaaca5d99", null ],
    [ "dma_set_dreq", "group___d_m_a.html#ga1a9a001dfad77a7c4a69d1b2223d0b48", null ],
    [ "dma_set_dst", "group___d_m_a.html#ga8cc9b9fdeff9175ae53ae664f2702a8f", null ],
    [ "dma_set_idle", "group___d_m_a.html#gae2c54c26c2ea91a050a8622dde9b3c3a", null ],
    [ "dma_set_init", "group___d_m_a.html#ga11048c70758f569cd1d3200e8eb8abb8", null ],
    [ "dma_set_int", "group___d_m_a.html#gad0871f2cacc1eaf9054ed1223f99dd68", null ],
    [ "dma_set_irq", "group___d_m_a.html#ga638f9dba12bf950942777a8e05f50995", null ],
    [ "dma_set_len", "group___d_m_a.html#ga300c5592602fd1ed4f39945d116b33c4", null ],
    [ "dma_set_prio", "group___d_m_a.html#ga2edf04928bfa9177eb422b01373a69ef", null ],
    [ "dma_set_req_mux_ch01", "group___d_m_a.html#gac32305ff3aacc8f4488af54660a85e9a", null ],
    [ "dma_set_req_mux_ch23", "group___d_m_a.html#ga5c0b8c3194d271fae8f01f12962e9ea3", null ],
    [ "dma_set_req_sense", "group___d_m_a.html#ga0a51fe097871a6ff6d8c86dbcbb67a54", null ],
    [ "dma_set_src", "group___d_m_a.html#gaf3acab6fb587e5b137f1fd73ea5ae349", null ],
    [ "dma_unfreeze", "group___d_m_a.html#gade693705b7810deecd555690c1c9d7d5", null ]
];