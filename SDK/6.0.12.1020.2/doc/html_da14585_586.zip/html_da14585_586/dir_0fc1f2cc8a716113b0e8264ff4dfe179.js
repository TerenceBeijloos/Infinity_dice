var dir_0fc1f2cc8a716113b0e8264ff4dfe179 =
[
    [ "adc", "dir_7e11b8ddc7aa8d17797d487053e577c3.html", "dir_7e11b8ddc7aa8d17797d487053e577c3" ],
    [ "battery", "dir_16fa96ef47231137c9d213f4457081a4.html", "dir_16fa96ef47231137c9d213f4457081a4" ],
    [ "dma", "dir_ac233787fe6ba8ec07212205ca59fb54.html", "dir_ac233787fe6ba8ec07212205ca59fb54" ],
    [ "gpio", "dir_9cc3b16bfa07915d834b30ab5a4dbd75.html", "dir_9cc3b16bfa07915d834b30ab5a4dbd75" ],
    [ "hw_otpc", "dir_f6984e5913f78ad48ec6de51accfde85.html", "dir_f6984e5913f78ad48ec6de51accfde85" ],
    [ "i2c", "dir_ed01316b6dd732773645451c423b54d5.html", "dir_ed01316b6dd732773645451c423b54d5" ],
    [ "i2c_eeprom", "dir_8efa23347767f367dda254c16827b649.html", "dir_8efa23347767f367dda254c16827b649" ],
    [ "pdm", "dir_d7ff4f7d16dc0fc95b8577fed4b298ef.html", "dir_d7ff4f7d16dc0fc95b8577fed4b298ef" ],
    [ "spi", "dir_4a3f43c839d30a4863a3f5f60e4e3af2.html", "dir_4a3f43c839d30a4863a3f5f60e4e3af2" ],
    [ "spi_flash", "dir_3c193985757fe53ca2d55dcf4793c25c.html", "dir_3c193985757fe53ca2d55dcf4793c25c" ],
    [ "syscntl", "dir_2bd9574aa78ec2c9053392c17bb508f1.html", "dir_2bd9574aa78ec2c9053392c17bb508f1" ],
    [ "systick", "dir_777e20b79ff8fa40bbe6e3a3329008c7.html", "dir_777e20b79ff8fa40bbe6e3a3329008c7" ],
    [ "timer", "dir_a0cec2eba655ecfa4ec0115583367a81.html", "dir_a0cec2eba655ecfa4ec0115583367a81" ],
    [ "trng", "dir_7cf0390fc8044be4714a8c50c0de6342.html", "dir_7cf0390fc8044be4714a8c50c0de6342" ],
    [ "uart", "dir_2ce41c795ea3d1b0d53e6724d109e1f8.html", "dir_2ce41c795ea3d1b0d53e6724d109e1f8" ],
    [ "wkupct_quadec", "dir_607ca75c56770e70018c2274d1421f21.html", "dir_607ca75c56770e70018c2274d1421f21" ]
];