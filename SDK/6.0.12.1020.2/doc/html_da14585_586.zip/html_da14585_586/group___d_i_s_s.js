var group___d_i_s_s =
[
    [ "app_diss.h", "app__diss_8h.html", null ],
    [ "app_dis_init", "group___d_i_s_s.html#ga69b5da1f00114001a0a54fcad65d4505", null ],
    [ "app_diss_create_db", "group___d_i_s_s.html#ga1dfa3234c8f94532dbbc87e988e24c7d", null ]
];