var arch__system_8h =
[
    [ "RCX_CALIB_TIME", "group___a_r_c_h___s_y_s_t_e_m.html#ga69a2386b45488c673dc22af0778f6c7e", null ],
    [ "arch_clk_is_RCX20", "group___a_r_c_h___s_y_s_t_e_m.html#gacde292edc922ea6d802f8c6b361d49b2", null ],
    [ "arch_clk_is_XTAL32", "group___a_r_c_h___s_y_s_t_e_m.html#ga24194ca668018ca4aff6cace06cd817c", null ],
    [ "arch_wkupct_tweak_deb_time", "group___a_r_c_h___s_y_s_t_e_m.html#ga032845630bd8cb7aca5df89e5a3e8bcf", null ],
    [ "conditionally_run_radio_cals", "group___a_r_c_h___s_y_s_t_e_m.html#ga1bde55b1fbf48f66baa27a4ef48a1e97", null ],
    [ "get_rc16m_count", "group___a_r_c_h___s_y_s_t_e_m.html#gadb0c3f990a4e4541de68ce0760938c3f", null ],
    [ "rcx20_calibrate", "group___a_r_c_h___s_y_s_t_e_m.html#ga897593fdd63285a6c67ab4f61ea1618d", null ],
    [ "rcx20_read_freq", "group___a_r_c_h___s_y_s_t_e_m.html#gadc24c47426ba75862ed04e7412c45f6e", null ],
    [ "system_init", "group___a_r_c_h___s_y_s_t_e_m.html#ga43f5e0d6db0fb41a437cc9096b32e9b5", null ],
    [ "xtal16m_trim_init", "group___a_r_c_h___s_y_s_t_e_m.html#ga72dc6dc7b3e3fc8c13823df29ec8053c", null ],
    [ "lp_clk_sel", "group___a_r_c_h___s_y_s_t_e_m.html#gadd14777771dadfe825bba39a49d3686f", null ]
];