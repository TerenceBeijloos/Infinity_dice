var adc__58x_8h =
[
    [ "ADC_TIMEOUT", "group___a_d_c.html#ga7825c3897a78747566304d9b44f087d2", null ],
    [ "adc_interrupt_cb_t", "group___a_d_c.html#ga043bbec5c7365b329e2fa7d6e7c77f7d", null ],
    [ "adc_input_diff_t", "group___a_d_c.html#gad6ace048983511b17cfa070f4354f9d0", [
      [ "ADC_INPUT_DIFF_P0_0_P0_1", "group___a_d_c.html#ggad6ace048983511b17cfa070f4354f9d0af9f1451943fea844b6549192c79ec95b", null ],
      [ "ADC_INPUT_DIFF_P0_2_P0_3", "group___a_d_c.html#ggad6ace048983511b17cfa070f4354f9d0ae1b9353d482b639ffc1f7b3c80961b5f", null ]
    ] ],
    [ "adc_input_mode_t", "group___a_d_c.html#ga8cd025ce4ccdf7ee0e601714fdbcf7ec", [
      [ "ADC_INPUT_MODE_DIFFERENTIAL", "group___a_d_c.html#gga8cd025ce4ccdf7ee0e601714fdbcf7eca04767d14c4a9f28c6ac92f16fa0a64b7", null ],
      [ "ADC_INPUT_MODE_SINGLE_ENDED", "group___a_d_c.html#gga8cd025ce4ccdf7ee0e601714fdbcf7eca74eaaf9f3db0340daa81a0804e75a93f", null ]
    ] ],
    [ "adc_input_se_t", "group___a_d_c.html#gac23bd0f898aa6001c8590474237c95b1", [
      [ "ADC_INPUT_SE_P0_0", "group___a_d_c.html#ggac23bd0f898aa6001c8590474237c95b1a883bec73d13fafc1529d348479d5e5b0", null ],
      [ "ADC_INPUT_SE_P0_1", "group___a_d_c.html#ggac23bd0f898aa6001c8590474237c95b1a338871223afc331e6773fe41d62d6e39", null ],
      [ "ADC_INPUT_SE_P0_2", "group___a_d_c.html#ggac23bd0f898aa6001c8590474237c95b1a4f1e4f2599df1e9f4528bf70a9bfb111", null ],
      [ "ADC_INPUT_SE_P0_3", "group___a_d_c.html#ggac23bd0f898aa6001c8590474237c95b1a5658d23645d0f79f94acab800f7d0cd1", null ],
      [ "ADC_INPUT_SE_AVS", "group___a_d_c.html#ggac23bd0f898aa6001c8590474237c95b1a39619ac0ea99e0fca0c6cd4578834f7b", null ],
      [ "ADC_INPUT_SE_VDD_REF", "group___a_d_c.html#ggac23bd0f898aa6001c8590474237c95b1a667ce0a1b1bc0884e90f45528a1fa270", null ],
      [ "ADC_INPUT_SE_VDD_RTT", "group___a_d_c.html#ggac23bd0f898aa6001c8590474237c95b1adb8889707031a188ec88749fd6bbe90f", null ],
      [ "ADC_INPUT_SE_VBAT3V", "group___a_d_c.html#ggac23bd0f898aa6001c8590474237c95b1a883fb5f55a8f54faa603c30b8bac5ae1", null ],
      [ "ADC_INPUT_SE_VDCDC", "group___a_d_c.html#ggac23bd0f898aa6001c8590474237c95b1ae0b532e2eed935198a2e01fbbdbd80e5", null ],
      [ "ADC_INPUT_SE_VBAT1V", "group___a_d_c.html#ggac23bd0f898aa6001c8590474237c95b1adff4d2e7f030b6cc589fa031dd36aa15", null ]
    ] ],
    [ "adc_get_vbat_sample", "group___a_d_c.html#ga128d517dad92de323e2ecb32e445194c", null ]
];