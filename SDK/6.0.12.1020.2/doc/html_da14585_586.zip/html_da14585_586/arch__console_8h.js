var arch__console_8h =
[
    [ "printf_msg", "group___arch__console.html#gaa64f9978438adfd8be6871a2382c69f1", null ],
    [ "arch_printf", "group___arch__console.html#ga2fccf9d1ac109c6cb0cfab2d4937e597", null ],
    [ "arch_printf_flush", "group___arch__console.html#gab4d63b01e9027bf2176e396ab3053738", null ],
    [ "arch_printf_process", "group___arch__console.html#ga047ae17df2c5c8fe7a8bb1f7011d7fbe", null ],
    [ "arch_puts", "group___arch__console.html#gaa01e27d70717addba726d86b82af5ee3", null ],
    [ "arch_vprintf", "group___arch__console.html#ga3d341c0fabf18c6dd8cf890943eca77e", null ]
];