var app__task_8h =
[
    [ "APP_IDX_MAX", "app__task_8h.html#a73524d6b1074d540fefedc1f65290905", null ],
    [ "APP_STATE", "app__task_8h.html#a6b8a24520a2e1d4d3820c581e85de70c", [
      [ "APP_DISABLED", "app__task_8h.html#a6b8a24520a2e1d4d3820c581e85de70caf90f56c681e8c5b4d5fc7ddc9ee51033", null ],
      [ "APP_DB_INIT", "app__task_8h.html#a6b8a24520a2e1d4d3820c581e85de70ca3409372680ada6ccbdd826f79b6abaa5", null ],
      [ "APP_CONNECTABLE", "app__task_8h.html#a6b8a24520a2e1d4d3820c581e85de70ca3687c57620f42343595daf916776e1be", null ],
      [ "APP_CONNECTED", "app__task_8h.html#a6b8a24520a2e1d4d3820c581e85de70cabf5bd60b968023a444eedcb0d83e2b50", null ],
      [ "APP_STATE_MAX", "app__task_8h.html#a6b8a24520a2e1d4d3820c581e85de70ca28be00a76cf90ceaa3aae32ea71c004e", null ]
    ] ],
    [ "app_gap_process_handler", "app__task_8h.html#af2c6e2c8d647c5e3efd865999ffb0d9d", null ],
    [ "app_default_handler", "app__task_8h.html#a344cbfcb45d5cf0a6c0d6a2d61806780", null ],
    [ "app_state", "app__task_8h.html#a3d9c9d81861fd56ed1cbcc4115b8865a", null ]
];