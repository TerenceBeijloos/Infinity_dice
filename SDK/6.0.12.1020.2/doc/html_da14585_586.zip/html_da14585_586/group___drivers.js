var group___drivers =
[
    [ "ADC", "group___a_d_c.html", "group___a_d_c" ],
    [ "Battery", "group___battery.html", "group___battery" ],
    [ "DMA", "group___d_m_a.html", "group___d_m_a" ],
    [ "GPIO", "group___g_p_i_o.html", "group___g_p_i_o" ],
    [ "OTP", "group___o_t_p.html", "group___o_t_p" ],
    [ "I2C", "group___i2_c.html", "group___i2_c" ],
    [ "I2C EEPROM", "group___i2_c___e_e_p_r_o_m.html", "group___i2_c___e_e_p_r_o_m" ],
    [ "PDM", "group___p_d_m.html", "group___p_d_m" ],
    [ "SPI", "group___s_p_i.html", "group___s_p_i" ],
    [ "SPI Flash", "group___s_p_i___flash.html", "group___s_p_i___flash" ],
    [ "SYSCNTL", "group___s_y_s_c_n_t_l.html", "group___s_y_s_c_n_t_l" ],
    [ "SysTick", "group___sys_tick.html", "group___sys_tick" ],
    [ "Timers", "group___timers.html", "group___timers" ],
    [ "TRNG", "group___t_r_n_g.html", "group___t_r_n_g" ],
    [ "UART", "group___u_a_r_t.html", "group___u_a_r_t" ],
    [ "WKUPCT / QUADEC", "group___w_k_u_p_c_t___q_u_a_d_e_c.html", "group___w_k_u_p_c_t___q_u_a_d_e_c" ]
];