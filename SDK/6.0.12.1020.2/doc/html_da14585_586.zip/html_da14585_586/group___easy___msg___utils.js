var group___easy___msg___utils =
[
    [ "app_easy_msg_utils.h", "app__easy__msg__utils_8h.html", null ],
    [ "app_easy_msg_free_callback", "group___easy___msg___utils.html#ga95ead30187d5a1f9bc67c0698f4c97de", null ],
    [ "app_easy_msg_modify", "group___easy___msg___utils.html#ga12e55955c70387d0618c400e13b72852", null ],
    [ "app_easy_msg_set", "group___easy___msg___utils.html#ga53188775c166c5e433dc923e1af80436", null ],
    [ "app_easy_wakeup", "group___easy___msg___utils.html#ga74401fc572d0fa745aa7fa146ed6682d", null ],
    [ "app_easy_wakeup_free", "group___easy___msg___utils.html#ga764c8cac378927ef59683183f73e6de0", null ],
    [ "app_easy_wakeup_set", "group___easy___msg___utils.html#gad3eb5f0a153ca8a9c9809a620ab7ce2a", null ],
    [ "app_msg_utils_api_process_handler", "group___easy___msg___utils.html#gab039168dff784a8b540edf873edc9bd0", null ]
];