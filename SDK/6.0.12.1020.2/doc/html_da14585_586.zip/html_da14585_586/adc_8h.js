var adc_8h =
[
    [ "adc_disable", "group___a_d_c.html#ga3b4b977d0665b5346849f3b892ac5106", null ],
    [ "adc_enable", "group___a_d_c.html#ga3afdea3b7c9b91013c270f1a1a669782", null ],
    [ "adc_get_input_mode", "group___a_d_c.html#ga974d2e690cf831c6afb176937e97e6cd", null ],
    [ "adc_get_offset_negative", "group___a_d_c.html#ga3ec4ef91b9a94fc21cb8df6ccda116b2", null ],
    [ "adc_get_offset_positive", "group___a_d_c.html#ga470447cd10b542f52ce6fe9ad96bd963", null ],
    [ "adc_get_sample", "group___a_d_c.html#ga9dad19596069f4ded0b824f8ddce49b2", null ],
    [ "adc_init", "group___a_d_c.html#ga5397d7276f8f90c59cf0842e0515df9a", null ],
    [ "adc_input_mute", "group___a_d_c.html#gaafe746f03498d70f05d32deb16ee32cf", null ],
    [ "adc_input_unmute", "group___a_d_c.html#ga25581bb4dcf352d39d3dd2d17907fa75", null ],
    [ "adc_offset_calibrate", "group___a_d_c.html#ga5d52ae4e1729fa0ae39b00ee574022a1", null ],
    [ "adc_register_interrupt", "group___a_d_c.html#ga5230388ae68ade677e61d9f9d1923b99", null ],
    [ "adc_reset", "group___a_d_c.html#ga81badb55f6183f8680189f895d510743", null ],
    [ "adc_set_diff_input", "group___a_d_c.html#ga99f67baeb8a0c7a8349b6689cb0c5288", null ],
    [ "adc_set_input_mode", "group___a_d_c.html#ga30c989aacaf83411a5f0dc10e39efa06", null ],
    [ "adc_set_offset_negative", "group___a_d_c.html#ga8db6b71645917ceb03a51764c7a938f1", null ],
    [ "adc_set_offset_positive", "group___a_d_c.html#gad050e20aef20005aded623bbfd9d8f62", null ],
    [ "adc_set_se_input", "group___a_d_c.html#ga5853f9435564ddc009e7cd0d0497d474", null ],
    [ "adc_sign_change_disable", "group___a_d_c.html#ga4edefa9e96b39df064fac5a84e8bfaad", null ],
    [ "adc_sign_change_enable", "group___a_d_c.html#ga96befacf63b49bbbb9c5b2e792171d79", null ],
    [ "adc_unregister_interrupt", "group___a_d_c.html#gaa7b713e36b7f5676a4f149b6b2c4f3f3", null ]
];