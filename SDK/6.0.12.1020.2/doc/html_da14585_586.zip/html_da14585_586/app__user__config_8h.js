var app__user__config_8h =
[
    [ "APP_CFG_ADDR_PUB", "group___user__config.html#ga2de608484fe159b891f15de055093418", null ],
    [ "APP_CFG_ADDR_SRC", "group___user__config.html#gaf40eef0810391cbceef518bb2a8ddf56", null ],
    [ "APP_CFG_ADDR_STATIC", "group___user__config.html#ga2173cfddc31f352f5ea43c0eb131f886", null ],
    [ "APP_CFG_ADDR_TYPE", "group___user__config.html#ga8f539d5da040fca4afd1018d2dc4d168", null ],
    [ "APP_CFG_CNTL_PRIV_MODE_DEVICE", "group___user__config.html#ga1be19ed526e3cd332d771f8bdc65bdfd", null ],
    [ "APP_CFG_CNTL_PRIV_MODE_NETWORK", "group___user__config.html#ga12b2171720fcdd64b25070fd8fcc65c1", null ],
    [ "APP_CFG_CNTL_PRIV_RPA_PUB", "group___user__config.html#ga83c99772ac204b80ae67c7bee47a079f", null ],
    [ "APP_CFG_CNTL_PRIV_RPA_RAND", "group___user__config.html#ga2bfc6de7e1a0bc917320151932d294a4", null ],
    [ "APP_CFG_HOST_PRIV_NRPA", "group___user__config.html#ga3ec6bff8aff16fa866800156eef1b657", null ],
    [ "APP_CFG_HOST_PRIV_RPA", "group___user__config.html#ga80c573fd1f39331f19ed50c2d1fd1c26", null ],
    [ "MS_TO_BLESLOTS", "group___user__config.html#gac1cc9a9524cdf8a0672bf73cf0fec1b2", null ],
    [ "MS_TO_DOUBLESLOTS", "group___user__config.html#gab66c9ad90a3c2d39882c08732ac224db", null ],
    [ "MS_TO_TIMERUNITS", "group___user__config.html#ga8e00eecd6d7fcedfb5109b09094780f8", null ],
    [ "US_TO_BLESLOTS", "group___user__config.html#ga07e3116b8937c4385cc6e7a865fb6593", null ],
    [ "US_TO_DOUBLESLOTS", "group___user__config.html#ga57975a3adfdfd201f48bc19758b74ea6", null ],
    [ "US_TO_TIMERUNITS", "group___user__config.html#ga86fb2f8124c4a938f034e3d67dd1896e", null ],
    [ "device_appearance_write_perm", "group___user__config.html#gabbfa56d3726dc3a6c6591708d9cf0033", [
      [ "APPEARANCE_WRITE_DISABLE", "group___user__config.html#ggabbfa56d3726dc3a6c6591708d9cf0033a3c12d708ff6b45cc2a715363fddcf2e1", null ],
      [ "APPEARANCE_WRITE_ENABLE", "group___user__config.html#ggabbfa56d3726dc3a6c6591708d9cf0033a9c8ff7128c1f635681cd98f640e05dbc", null ],
      [ "APPEARANCE_WRITE_UNAUTH", "group___user__config.html#ggabbfa56d3726dc3a6c6591708d9cf0033a4f9197ebcd79e3289f5405480e22cbae", null ],
      [ "APPEARANCE_WRITE_AUTH", "group___user__config.html#ggabbfa56d3726dc3a6c6591708d9cf0033a9ccccd76ed25823736ffbd4db32d104b", null ]
    ] ],
    [ "device_name_write_perm", "group___user__config.html#ga085bf6a0b35d7bdf7dd56e792630cf73", [
      [ "NAME_WRITE_DISABLE", "group___user__config.html#gga085bf6a0b35d7bdf7dd56e792630cf73a0c454014d57a29758384934107134f0c", null ],
      [ "NAME_WRITE_ENABLE", "group___user__config.html#gga085bf6a0b35d7bdf7dd56e792630cf73a16014da9bc01417613002c072dc9df6e", null ],
      [ "NAME_WRITE_UNAUTH", "group___user__config.html#gga085bf6a0b35d7bdf7dd56e792630cf73a54d2eede3d86d070e5ca961a7b4335ff", null ],
      [ "NAME_WRITE_AUTH", "group___user__config.html#gga085bf6a0b35d7bdf7dd56e792630cf73a92ed35e75954f690e3a4bb655907e86d", null ]
    ] ]
];