var group___c_t_s_c =
[
    [ "app_ctsc.h", "app__ctsc_8h.html", null ],
    [ "app_ctsc_cb", "structapp__ctsc__cb.html", [
      [ "on_connect", "structapp__ctsc__cb.html#ab976b9267d2cdfa39dc0fec96a1c7ae4", null ],
      [ "on_ct_read", "structapp__ctsc__cb.html#ab9dd077f24d8bf6d725a48be9536ef05", null ],
      [ "on_ct_write", "structapp__ctsc__cb.html#a76d9d18edd96ab7bfe02e88f4f7d08d5", null ],
      [ "on_desc_read", "structapp__ctsc__cb.html#a633d010c547c40500615b8c2097b1810", null ],
      [ "on_desc_write", "structapp__ctsc__cb.html#a71d60e500d460403f999615a7d67f091", null ],
      [ "on_lti_read", "structapp__ctsc__cb.html#a494162511d63e22cd3147db43221e0e9", null ],
      [ "on_lti_write", "structapp__ctsc__cb.html#a6b09bfbcbcfc80939a477a384c4819c6", null ],
      [ "on_rti_read", "structapp__ctsc__cb.html#a8db8b4b08cea85344e8c2f1fc38abd11", null ]
    ] ],
    [ "app_ctsc_create_task", "group___c_t_s_c.html#gaf66a0002fc513c8a6e0f31137c019718", null ],
    [ "app_ctsc_enable", "group___c_t_s_c.html#gaa4241f63253aebc993d51647b89037b1", null ],
    [ "app_ctsc_init", "group___c_t_s_c.html#ga8db5c4c233a5c5aa4bb3c15ebd8d7637", null ],
    [ "app_ctsc_read_ct", "group___c_t_s_c.html#ga6bd5c23438f76863932d605c385d66cc", null ],
    [ "app_ctsc_read_desc", "group___c_t_s_c.html#ga70e3c7a72b2d311170fd4aedfb43c58b", null ],
    [ "app_ctsc_read_lti", "group___c_t_s_c.html#ga7eb94419936d142c98965ee2a77abd64", null ],
    [ "app_ctsc_read_rti", "group___c_t_s_c.html#ga60f262d1db8d33fe1b9827e805321973", null ],
    [ "app_ctsc_write_ct", "group___c_t_s_c.html#ga9782b4d052d10b1a547ae77b3e440bbe", null ],
    [ "app_ctsc_write_desc", "group___c_t_s_c.html#gaed144075fd5632c11ead9d60cded19d6", null ],
    [ "app_ctsc_write_lti", "group___c_t_s_c.html#ga4e9d007b0aa1f0e12b12aa2bc0874f43", null ]
];