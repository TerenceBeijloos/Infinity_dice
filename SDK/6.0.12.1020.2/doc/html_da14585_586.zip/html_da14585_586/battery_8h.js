var battery_8h =
[
    [ "BATTERY_MEASUREMENT_BOOST_AT_0V8", "group___battery.html#ga84f46e40c7f9577b2a3cee2f97f14e6e", null ],
    [ "BATTERY_MEASUREMENT_BOOST_AT_0V9", "group___battery.html#ga8252d0f379c5a0a4293ace398ced0b74", null ],
    [ "BATTERY_MEASUREMENT_BOOST_AT_1V0", "group___battery.html#ga8b74fdec6e55dde05dd07206ad7169ee", null ],
    [ "BATTERY_MEASUREMENT_BOOST_AT_1V5", "group___battery.html#ga84ce4610f1e50c02d9d0d4b4cbed4b59", null ],
    [ "BATTERY_MEASUREMENT_BUCK_AT_2V4", "group___battery.html#ga76964bd3bbe12e85a5dc23013528ec8a", null ],
    [ "BATTERY_MEASUREMENT_BUCK_AT_2V6", "group___battery.html#ga37cfb6b185455597aa3f546d7e19308c", null ],
    [ "BATTERY_MEASUREMENT_BUCK_AT_2V8", "group___battery.html#gadbf547a8393dde342f3c6c8c1795b580", null ],
    [ "BATTERY_MEASUREMENT_BUCK_AT_3V0", "group___battery.html#gaa09c06a7a6092dc7a0f537beef0a0b2c", null ],
    [ "batt_t", "group___battery.html#ga28e12856e4c0bf56a588645ddd39ec7f", [
      [ "BATT_CR2032", "group___battery.html#gga28e12856e4c0bf56a588645ddd39ec7fa45aad6e0a30070b8fbd62fcf832cfcd3", null ],
      [ "BATT_CR1225", "group___battery.html#gga28e12856e4c0bf56a588645ddd39ec7faf1e7f5cb8b62addb8292f4968bdfd633", null ],
      [ "BATT_AAA", "group___battery.html#gga28e12856e4c0bf56a588645ddd39ec7facddca924cacf28b7876f3a5c650575f1", null ]
    ] ],
    [ "battery_get_lvl", "group___battery.html#ga3de6b950c9008ca44c9d1a84e3b12018", null ]
];