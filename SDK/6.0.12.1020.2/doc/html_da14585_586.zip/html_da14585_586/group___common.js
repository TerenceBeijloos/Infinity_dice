var group___common =
[
    [ "app.h", "app_8h.html", null ],
    [ "app_env_tag", "structapp__env__tag.html", [
      [ "conhdl", "structapp__env__tag.html#a79b9ce888cdd1a90ff1653ed6e289398", null ],
      [ "conidx", "structapp__env__tag.html#a412eaef727af88356d73d804decb7def", null ],
      [ "connection_active", "structapp__env__tag.html#a87e254d8dce10101e966e69fbc4ebddc", null ],
      [ "pairing_in_progress", "structapp__env__tag.html#a673969690dec9241ec74e399b9cfbbef", null ],
      [ "peer_addr", "structapp__env__tag.html#ab7f839b3fd9b50fde603a0c65816c96e", null ],
      [ "peer_addr_type", "structapp__env__tag.html#a9a94745b8d082358c4f08761aff6d541", null ]
    ] ],
    [ "app_device_name", "structapp__device__name.html", [
      [ "length", "structapp__device__name.html#ae2242cde05e310c6021f0cb1f915bae0", null ],
      [ "name", "structapp__device__name.html#a2225194758f7841047ba06916d7ec65f", null ]
    ] ],
    [ "app_device_info", "structapp__device__info.html", [
      [ "appearance", "structapp__device__info.html#ac0127344d3d7482a8db26acd81b7bf26", null ],
      [ "dev_name", "structapp__device__info.html#a3ae1ded96827eb2a7169b91960406138", null ]
    ] ],
    [ "APP_ADV_DATA_MAX_SIZE", "group___common.html#ga26332ce3f2f99b94fb39b53c67648701", null ],
    [ "APP_EASY_MAX_ACTIVE_CONNECTION", "group___common.html#gaa9b9b8a17df0b6c0298cc817ff22e25b", null ],
    [ "APP_SCAN_RESP_DATA_MAX_SIZE", "group___common.html#ga53eba71f1d302f1e24bd020d37223a97", null ],
    [ "APP_MSG", "group___common.html#ga76307e3ff0d3b4126c990c031a4c9126", [
      [ "APP_MODULE_INIT_CMP_EVT", "group___common.html#gga76307e3ff0d3b4126c990c031a4c9126a24e45191486f745dab54f76c4dd7784b", null ],
      [ "APP_CREATE_TIMER", "group___common.html#gga76307e3ff0d3b4126c990c031a4c9126a085ec70d808a3b6b3733a4b6401c2437", null ],
      [ "APP_CANCEL_TIMER", "group___common.html#gga76307e3ff0d3b4126c990c031a4c9126a33716d9117125d7f2407b7c677078e38", null ],
      [ "APP_MODIFY_TIMER", "group___common.html#gga76307e3ff0d3b4126c990c031a4c9126a62858ad30a086fc6c46cabb7a5f90c40", null ],
      [ "APP_TIMER_API_MES0", "group___common.html#gga76307e3ff0d3b4126c990c031a4c9126a4e463e85dca94dcbad147ada7b5187ba", null ],
      [ "APP_TIMER_API_MES1", "group___common.html#gga76307e3ff0d3b4126c990c031a4c9126a4a7410e7e9e1b3a64d9c84e660c443f6", null ],
      [ "APP_TIMER_API_MES2", "group___common.html#gga76307e3ff0d3b4126c990c031a4c9126ab79b57e04795464e4264ae0dae938973", null ],
      [ "APP_TIMER_API_MES3", "group___common.html#gga76307e3ff0d3b4126c990c031a4c9126a5184fa59864a33a13af04f6fcc966909", null ],
      [ "APP_TIMER_API_MES4", "group___common.html#gga76307e3ff0d3b4126c990c031a4c9126a7d9350fdcefd18005e2b4e5b090d8997", null ],
      [ "APP_TIMER_API_MES5", "group___common.html#gga76307e3ff0d3b4126c990c031a4c9126a7635cf176f501ad095111505780219fb", null ],
      [ "APP_TIMER_API_MES6", "group___common.html#gga76307e3ff0d3b4126c990c031a4c9126a4db622267aefb561b5f3aed9112e0996", null ],
      [ "APP_TIMER_API_MES7", "group___common.html#gga76307e3ff0d3b4126c990c031a4c9126a091c6662db441d806847ddcb49fc61d7", null ],
      [ "APP_TIMER_API_MES8", "group___common.html#gga76307e3ff0d3b4126c990c031a4c9126a416eaaee56a2308e18ea9028bbf8e471", null ],
      [ "APP_TIMER_API_MES9", "group___common.html#gga76307e3ff0d3b4126c990c031a4c9126a3eb81686a33e8997cd1d0d4ab61b8ca2", null ],
      [ "APP_TIMER_API_LAST_MES", "group___common.html#gga76307e3ff0d3b4126c990c031a4c9126aebfd8f18f4783df992c5b775a8c4e6ee", null ],
      [ "APP_MSG_UTIL_API_MES0", "group___common.html#gga76307e3ff0d3b4126c990c031a4c9126a05745086abb8b6ddc05b254c5a61aa1d", null ],
      [ "APP_MSG_UTIL_API_MES1", "group___common.html#gga76307e3ff0d3b4126c990c031a4c9126aa02c872e42b0919e3c75f5576cf8411b", null ],
      [ "APP_MSG_UTIL_API_MES2", "group___common.html#gga76307e3ff0d3b4126c990c031a4c9126a86105f6d140e53a59a05bff3fcb316e9", null ],
      [ "APP_MSG_UTIL_API_MES3", "group___common.html#gga76307e3ff0d3b4126c990c031a4c9126a91dc8fa6e88cf52ba10cad1b91973914", null ],
      [ "APP_MSG_UTIL_API_MES4", "group___common.html#gga76307e3ff0d3b4126c990c031a4c9126a4fbcb492bc09e6d3157a69799404700a", null ],
      [ "APP_MSG_UTIL_API_LAST_MES", "group___common.html#gga76307e3ff0d3b4126c990c031a4c9126a54b5e3fd09214ae7560a304314bff298", null ],
      [ "APP_PROXR_TIMER", "group___common.html#gga76307e3ff0d3b4126c990c031a4c9126ad97c04b9b27936a8a2e7cf47d3f885b4", null ],
      [ "APP_FINDT_TIMER", "group___common.html#gga76307e3ff0d3b4126c990c031a4c9126affd845c5480df3c8e92c6d2127fc3ce3", null ],
      [ "APP_BASS_TIMER", "group___common.html#gga76307e3ff0d3b4126c990c031a4c9126a7986fb33b8b4e1d5c252b7f6161fc57a", null ],
      [ "APP_BASS_ALERT_TIMER", "group___common.html#gga76307e3ff0d3b4126c990c031a4c9126ac876c5f7881d171bad6f8079bb54151f", null ]
    ] ],
    [ "app_db_init", "group___common.html#ga51262358796ac00fab80ad3569203c1f", null ],
    [ "app_db_init_start", "group___common.html#ga8fca6c21ae07d1c18722d302c69c00e2", null ],
    [ "app_gattc_svc_changed_cmd_send", "group___common.html#ga802a89c3c805b59fe02d5878e8247189", null ],
    [ "app_init", "group___common.html#gadd3190cf715f513666f4be42874d91e2", null ],
    [ "app_prf_enable", "group___common.html#ga4aaedcec7a38100a186e23b11aa660c2", null ],
    [ "app_timer_set", "group___common.html#ga65c1449b94b3c51eb8d22790318f9c83", null ],
    [ "app_env", "group___common.html#gab5b4c15b7083668573b3462a974f8da3", null ],
    [ "device_info", "group___common.html#ga7c188af11cd729043f64d6fdf2215168", null ]
];