var app__default__handlers_8h =
[
    [ "default_advertise_scenario", "group___default___handlers.html#gab84fedb06927f9388ed8d639ac93e9bf", [
      [ "DEF_ADV_FOREVER", "group___default___handlers.html#ggab84fedb06927f9388ed8d639ac93e9bfa5dc77893c9663290c969dbf8d9e46783", null ],
      [ "DEF_ADV_WITH_TIMEOUT", "group___default___handlers.html#ggab84fedb06927f9388ed8d639ac93e9bfa72f258a1f811ad20c5ca1fb6cd6d761d", null ]
    ] ],
    [ "default_security_request_scenario", "group___default___handlers.html#ga1bb5c7fe5392254c5d04a9932f322eeb", [
      [ "DEF_SEC_REQ_NEVER", "group___default___handlers.html#gga1bb5c7fe5392254c5d04a9932f322eebae8e1ea6180acc277284c1c073e2a8d69", null ],
      [ "DEF_SEC_REQ_ON_CONNECT", "group___default___handlers.html#gga1bb5c7fe5392254c5d04a9932f322eeba40cf5c13925028955abff1d1d7b338c0", null ]
    ] ],
    [ "default_advertise_operation", "group___default___handlers.html#ga49d4e936209aa862d2666b4701f172bd", null ],
    [ "default_app_generate_static_random_addr", "group___default___handlers.html#gaf8651c84a65178c3a2ad732835e97937", null ],
    [ "default_app_generate_unique_static_random_addr", "group___default___handlers.html#ga6ef694d957c80580c2ad2395db855b92", null ],
    [ "default_app_on_addr_resolve_failed", "group___default___handlers.html#ga1e61905d9ab78359cf97c72c79df7587", null ],
    [ "default_app_on_addr_solved_ind", "group___default___handlers.html#ga94d470b3f72224ceffb3fb38827ce2ff", null ],
    [ "default_app_on_connection", "group___default___handlers.html#ga3427f0137c354dd9363708631c301585", null ],
    [ "default_app_on_csrk_exch", "group___default___handlers.html#gae4ea20c0367bee476d814601f58d872f", null ],
    [ "default_app_on_db_init_complete", "group___default___handlers.html#gab485c89426c3cef9b63bed170c849bae", null ],
    [ "default_app_on_disconnect", "group___default___handlers.html#ga94285c7d4ef8b1805997d9075bb8750f", null ],
    [ "default_app_on_encrypt_req_ind", "group___default___handlers.html#ga3c0cd70627bcbe089b22d4f05ab52d29", null ],
    [ "default_app_on_get_dev_appearance", "group___default___handlers.html#gaac39a9fc3aa7d1bde5d4037997d740bc", null ],
    [ "default_app_on_get_dev_name", "group___default___handlers.html#ga1a5e2e2774d115516587b8d0e1a36993", null ],
    [ "default_app_on_get_dev_slv_pref_params", "group___default___handlers.html#gab2186b2a547c7d0ec3153f16d6f85ffa", null ],
    [ "default_app_on_init", "group___default___handlers.html#gac9b97d67ab4fbf7a02910b9a28dca383", null ],
    [ "default_app_on_ltk_exch", "group___default___handlers.html#ga73fc770c3c5e66360600e8b88f89929d", null ],
    [ "default_app_on_pairing_request", "group___default___handlers.html#ga020d400dc1e92f33deb7ecc6bdfd8b00", null ],
    [ "default_app_on_pairing_succeeded", "group___default___handlers.html#ga3d2fbec3b52618d6b070558073260782", null ],
    [ "default_app_on_ral_cmp_evt", "group___default___handlers.html#gac241bd2a043a15b47d696cb3c6bea3d3", null ],
    [ "default_app_on_set_dev_config_complete", "group___default___handlers.html#ga4e82afad3fe875cdc86f10808adb6e09", null ],
    [ "default_app_on_set_dev_info", "group___default___handlers.html#ga3b95ae26c2b60ff40e6cfa14e0a42a86", null ],
    [ "default_app_on_tk_exch", "group___default___handlers.html#gadcb8b723b398d8ef1acb828c433cebe2", null ],
    [ "default_app_update_params_request", "group___default___handlers.html#ga59893390e169ae3cc357c86f283428d4", null ]
];