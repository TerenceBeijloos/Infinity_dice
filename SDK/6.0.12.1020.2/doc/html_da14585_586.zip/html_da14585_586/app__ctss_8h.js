var app__ctss_8h =
[
    [ "app_ctss_create_db", "group___c_t_s_s.html#gab1b5bf63a7b5747a57d3edea0598d0bc", null ],
    [ "app_ctss_init", "group___c_t_s_s.html#ga1ccf490d8b882a478b1a8ffdc2ae27f1", null ],
    [ "app_ctss_notify_current_time", "group___c_t_s_s.html#ga79023ffab2cda029e213f474d3c5c940", null ]
];