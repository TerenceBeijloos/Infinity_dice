var arch__rom_8h =
[
    [ "MAX_HEADER_SIZE", "group___a_r_c_h___r_o_m.html#gab4ef65077affc5d61e2b41556d4b8387", null ],
    [ "H4TL", "group___a_r_c_h___r_o_m.html#gae906a53899c8eed244d88940b0c9b4db", [
      [ "H4TL_STATE_TX_ONGOING", "group___a_r_c_h___r_o_m.html#ggae906a53899c8eed244d88940b0c9b4dbaed612105745dcc4192b88c1ced42f14d", null ],
      [ "H4TL_STATE_TX_IDLE", "group___a_r_c_h___r_o_m.html#ggae906a53899c8eed244d88940b0c9b4dba0ccb207f110ce5aa3b36fc714a610098", null ]
    ] ],
    [ "H4TL_STATE_RX", "group___a_r_c_h___r_o_m.html#ga925c891fd57ba111049052d45d3da474", [
      [ "H4TL_STATE_RX_START", "group___a_r_c_h___r_o_m.html#gga925c891fd57ba111049052d45d3da474a0bb225209dc9822deecb34bf96a3d8c0", null ],
      [ "H4TL_STATE_RX_HDR", "group___a_r_c_h___r_o_m.html#gga925c891fd57ba111049052d45d3da474a43613b27e99ccfde18a33662a67b3756", null ],
      [ "H4TL_STATE_RX_PAYL", "group___a_r_c_h___r_o_m.html#gga925c891fd57ba111049052d45d3da474a3d17a04856c0650e9c3c6cd7e93946c2", null ],
      [ "H4TL_STATE_RX_OUT_OF_SYNC", "group___a_r_c_h___r_o_m.html#gga925c891fd57ba111049052d45d3da474a0d34e3d41d7c4dd3a3e64732c369a0b8", null ]
    ] ],
    [ "arch_rom_init", "group___a_r_c_h___r_o_m.html#ga62608f45677872f5e77862d4e9a8a4bc", null ],
    [ "gap_cfg_user_var_struct", "group___a_r_c_h___r_o_m.html#ga80a7ccb9501a6ba723fa2ad2b0d2a34c", null ],
    [ "h4tl_env", "group___a_r_c_h___r_o_m.html#ga00e064a2de103b5c8483b2df9ffd8334", null ],
    [ "hci_cmd_desc_root_tab", "group___a_r_c_h___r_o_m.html#ga4f88707b54e80efd6f5ed4f4b9d3725a", null ],
    [ "length_exchange_needed", "group___a_r_c_h___r_o_m.html#ga9591f807956b8998020104b06f03d132", null ],
    [ "rom_cfg_table", "group___a_r_c_h___r_o_m.html#ga9e9a648f760369aac567b0bee2667a20", null ],
    [ "rom_cfg_table_var", "group___a_r_c_h___r_o_m.html#ga97d1d409cb84f7b68a1040573c59c30e", null ],
    [ "rom_func_addr_table", "group___a_r_c_h___r_o_m.html#gacd607e13707a17adf2cee6770280cb1b", null ],
    [ "rom_func_addr_table_var", "group___a_r_c_h___r_o_m.html#ga3c719ae8f2de734383a8c5b73ec36474", null ],
    [ "rom_hci_cmd_desc_root_tab", "group___a_r_c_h___r_o_m.html#ga01294a2bc2d09203ec057e3658f02cae", null ],
    [ "use_h4tl", "group___a_r_c_h___r_o_m.html#gaaa7d9737d087453e984ec4d1afe1c240", null ]
];